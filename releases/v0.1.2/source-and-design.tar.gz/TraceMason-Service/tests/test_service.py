import asyncio
import base64
import gzip
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import aiohttp
from aiohttp import web, WSMsgType
from multidict import CIMultiDict
from yarl import URL
from cryptography.exceptions import InvalidTag
from accounts.credential_store import CredentialStore, load_master_key
from accounts.repository import AccountRepository
from server import create_app, REPO, GATEWAY, GATEWAY_URL, EVENTS


async def listen(app):
    runner = web.AppRunner(app, access_log=None, handler_cancellation=True)
    await runner.setup()
    site = web.TCPSite(runner, '127.0.0.1', 0)
    await site.start()
    return runner, 'http://127.0.0.1:' + str(site._server.sockets[0].getsockname()[1])


def account(account_id, base, kind='openai', key='test-key-A'):
    return dict(id=account_id, intent='create', name=account_id, provider_kind=kind,
        base_url=base, credential_mode='managed', api_key=key, api_key_env='', model='',
        protocol='responses', model_mode='preserve', auth_type='x_api_key' if kind=='claude' else 'bearer')


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path = Path(self.directory.name)
        self.key = os.urandom(32)
        self.seen = []
        self.stream_release = asyncio.Event()
        self.check_started = asyncio.Event()
        self.check_release = asyncio.Event()
        self.disconnected = asyncio.Event()
        async def upstream(request):
            raw = await request.read()
            self.seen.append((request.method, request.raw_path, dict(request.headers), raw))
            try: scenario=json.loads(raw).get('model','') if raw else ''
            except (ValueError,AttributeError): scenario=''
            route='/'+scenario.removeprefix('test__') if scenario.startswith('test__') else request.path
            if route.endswith('/ws'):
                ws = web.WebSocketResponse(protocols=['realtime'], autoping=False)
                ws.headers['X-Upstream-Handshake']='preserved'
                await ws.prepare(request)
                async for msg in ws:
                    if msg.type == WSMsgType.TEXT: await ws.send_str(msg.data)
                    elif msg.type == WSMsgType.BINARY: await ws.send_bytes(msg.data)
                    elif msg.type == WSMsgType.PING: await ws.pong(msg.data)
                return ws
            if route.endswith('/close-ws'):
                ws = web.WebSocketResponse()
                await ws.prepare(request)
                await ws.close(code=4001, message=b'finished')
                return ws
            if route.endswith('/redirect'):
                return web.Response(status=307, body=b'redirect-raw', headers={'Location': '/capture'})
            if route.endswith('/denied'):
                return web.Response(status=401, body=b'upstream-auth-error', headers={'X-Upstream': 'kept'})
            if route.endswith('/blocked-check'):
                self.check_started.set()
                await self.check_release.wait()
            if route.endswith('/stream'):
                response = web.StreamResponse(headers={'Content-Type': 'text/event-stream'})
                await response.prepare(request)
                await response.write(b'data: first\n\n')
                await self.stream_release.wait()
                await response.write(b'data: last\n\n')
                return response
            if route.endswith('/cancel'):
                response = web.StreamResponse(headers={'Content-Type': 'text/event-stream'})
                await response.prepare(request)
                await response.write(b'first')
                try: await asyncio.Event().wait()
                finally: self.disconnected.set()
            if route.endswith('/gzip'):
                return web.Response(body=gzip.compress(b'compressed-response'), headers={'Content-Encoding': 'gzip'})
            return web.Response(body=raw, headers=CIMultiDict([('X-Upstream', 'kept'), ('Set-Cookie', 'a=1'), ('Set-Cookie', 'b=2')]))
        up = web.Application(client_max_size=0, handler_args={'auto_decompress': False})
        up.router.add_route('*', '/{tail:.*}', upstream)
        self.up_runner, self.up_url = await listen(up)
        self.app = create_app(self.path / 'accounts.db', self.key, check_timeout=2)
        self.proxy_runner, self.proxy_url = await listen(self.app[GATEWAY])
        self.app[GATEWAY_URL] = self.proxy_url
        self.runner, self.url = await listen(self.app)
        self.client = aiohttp.ClientSession(auto_decompress=False, cookie_jar=aiohttp.DummyCookieJar())
        async with self.client.get(self.url+'/api/session') as r:
            self.token = (await r.json())['token']
        self.etag = (await self.client.get(self.url+'/api/providers')).headers['ETag']

    async def asyncTearDown(self):
        self.stream_release.set()
        self.check_release.set()
        await self.client.close()
        await self.proxy_runner.cleanup()
        await self.runner.cleanup()
        await self.up_runner.cleanup()
        self.directory.cleanup()

    async def api(self, path, body=None, method='POST', tag=None):
        async with self.client.request(method, self.url+path, json=body,
              headers={'X-TraceMason-Token': self.token, 'If-Match': tag or self.etag}) as response:
            if response.headers.get('ETag'): self.etag = response.headers['ETag']
            return response.status, await response.json()

    async def add(self, id='one', kind='openai', key='test-key-A'):
        status, body = await self.api('/api/providers', account(id, self.up_url+'/root', kind, key))
        self.assertEqual(status, 200, body)
        return body

    async def test_crud_cas_encryption_and_restore(self):
        before = self.etag
        body = await self.add()
        self.assertTrue(body['providers']['one']['has_api_key'])
        self.assertNotIn('test-key-A', json.dumps(body))
        status, _ = await self.api('/api/providers/enabled', {'id':'one', 'enabled':False}, tag=before)
        self.assertEqual(status, 412)
        item = account('one', self.up_url+'/root', key='')
        item.update(intent='update', name='renamed')
        status, body = await self.api('/api/providers', item)
        self.assertEqual(status, 200)
        self.assertEqual(body['providers']['one']['credential_revision'], 1)
        item['api_key'] = 'replacement-key'
        await self.api('/api/providers', item)
        repo = self.app[REPO]
        self.assertEqual((await repo.call('resolve','one'))['key'], 'replacement-key')
        old_tag = (await repo.call('view'))[1]
        with patch.object(repo.repo.credentials, 'encrypt', side_effect=sqlite3.OperationalError('simulated disk failure')):
            status, body = await self.api('/api/providers', dict(item, api_key='rollback-key'))
        self.assertEqual(status, 500)
        self.assertEqual((await repo.call('view'))[1], old_tag)
        self.assertEqual((await repo.call('resolve','one'))['key'], 'replacement-key')
        def backup_db():
            with sqlite3.connect(self.path/'backup.db') as backup:repo.repo.db.backup(backup)
        await asyncio.get_running_loop().run_in_executor(repo.executor,backup_db)
        from accounts.service import AccountService
        restored = AccountService(self.path/'backup.db',self.key)
        self.assertEqual((await restored.call('resolve','one'))['key'], 'replacement-key')
        await restored.close()
        with self.assertRaises(InvalidTag): AccountRepository(self.path/'backup.db', CredentialStore(os.urandom(32)))
        for file in self.path.iterdir():
            for secret in (b'test-key-A', b'replacement-key', b'rollback-key'):
                self.assertNotIn(secret, file.read_bytes())
        await self.api('/api/providers/one', method='DELETE')
        async with self.client.get(self.proxy_url+'/proxy/one/capture') as r: self.assertEqual(r.status,404)
        self.assertGreater(sqlite3.connect(self.path/'accounts.db').execute('SELECT count(*) FROM audit').fetchone()[0], 0)

    async def test_three_providers_arbitrary_model_and_protocol_fields(self):
        for kind,path in [('openai','/responses'),('deepseek','/chat/completions'),('claude','/messages')]:
            await self.add(kind,kind,'key-'+kind)
            doc={'model':'future/unknown-v999','input':'ordinary','messages':[{'role':'user','content':'ordinary'}], 'unknown':{'flag':True},'stream':False}
            async with self.client.post(self.proxy_url+'/proxy/'+kind+path,json=doc,headers={'X-Extra':'secret-header','Anthropic-Version':'2099-01-01','Cookie':'secret-cookie'}) as r:
                self.assertEqual(r.status,200);self.assertEqual(await r.json(content_type=None),doc)
            method,route,headers,raw=self.seen[-1]
            self.assertEqual(route,'/root'+path);self.assertNotIn('X-Extra',headers);self.assertNotIn('Cookie',headers)
            self.assertEqual(headers['x-api-key'] if kind=='claude' else headers['Authorization'],'key-'+kind if kind=='claude' else 'Bearer key-'+kind)

    async def test_opaque_uploads_and_websocket_fail_closed(self):
        await self.add()
        for raw,content,extras in [(b'opaque','application/octet-stream',{}),(b'--boundary','multipart/form-data',{}),(gzip.compress(b'text'),'application/json',{'Content-Encoding':'gzip'})]:
            async with self.client.post(self.proxy_url+'/proxy/one/responses',data=raw,headers={'Content-Type':content,**extras}) as r:self.assertEqual(r.status,422)
        with self.assertRaises(aiohttp.WSServerHandshakeError):await self.client.ws_connect(self.proxy_url+'/proxy/one/ws')
        self.assertEqual(self.seen,[])

    async def test_streaming_snapshot_disable_and_cancellation(self):
        await self.add()
        async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'model':'test__stream','input':'hello'}) as r:
            self.assertEqual(await asyncio.wait_for(r.content.readexactly(13),1),b'data: first\n\n')
            await self.api('/api/providers/enabled',{'id':'one','enabled':False})
            async with self.client.get(self.proxy_url+'/proxy/one/capture') as disabled:self.assertEqual(disabled.status,409)
            self.stream_release.set()
            self.assertEqual(await r.read(),b'data: last\n\n')
        await self.api('/api/providers/enabled',{'id':'one','enabled':True})
        r = await self.client.post(self.proxy_url+'/proxy/one/responses',json={'model':'test__cancel','input':'hello'})
        self.assertEqual(await r.content.readexactly(5),b'first')
        r.close()
        await asyncio.wait_for(self.disconnected.wait(),2)

    async def test_upstream_errors_and_redirect_preserved(self):
        await self.add()
        for path,status,body in [('denied',401,b'upstream-auth-error'),('redirect',307,b'redirect-raw')]:
            async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'model':'test__'+path,'input':'hello'},allow_redirects=False) as r:
                self.assertEqual(r.status,status);self.assertEqual(await r.read(),body)
            self.assertEqual(json.loads(self.seen[-1][3])['model'],'test__'+path)

    async def test_ops_failure_no_disable_and_stale_probe_not_overwrite(self):
        await self.add()
        spec={'method':'POST','path':'/responses','headers':{'Content-Type':'application/json'},'body':json.dumps({'model':'test__denied','input':'hi'})}
        status,body=await self.api('/api/providers/test',{'id':'one','request':spec})
        self.assertEqual(status,200);self.assertEqual(body['error_code'],'upstream_auth');self.assertEqual(body['scope'],'custom_request_only')
        self.assertTrue((await self.app[REPO].call('snapshot'))['providers']['one']['enabled'])
        task=asyncio.create_task(self.api('/api/providers/test',{'id':'one','request':dict(spec,body=json.dumps({'model':'test__blocked-check','input':'hi'}))}))
        await self.check_started.wait()
        await self.api('/api/providers',dict(account('one',self.up_url+'/root',key='new-key'),intent='update'))
        self.check_release.set()
        await task
        self.assertIsNone((await self.app[REPO].call('snapshot'))['providers']['one']['probe'])
        self.assertEqual(sqlite3.connect(self.path/'accounts.db').execute('SELECT count(*) FROM checks').fetchone()[0],2)
        await self.api('/api/providers/one',method='DELETE')
        self.assertEqual(sqlite3.connect(self.path/'accounts.db').execute('SELECT count(*) FROM checks').fetchone()[0],2)

    async def test_security_and_no_ui_mock(self):
        for headers in [{'Host':'attacker.example'}, {'Origin':'https://attacker.example'}, {'Sec-Fetch-Site':'cross-site'}]:
            async with self.client.get(self.url+'/api/session',headers=headers) as r:self.assertEqual(r.status,403)
        async with self.client.post(self.url+'/api/providers',json={}) as r:self.assertEqual(r.status,403)
        await self.add()
        async with self.client.post(self.url+'/api/providers/enabled',json={'id':'one','enabled':False},headers={'X-TraceMason-Token':self.token}) as r:self.assertEqual(r.status,428)
        async with self.client.get(URL(self.proxy_url+'/proxy/one/%2e%2e/escape',encoded=True)) as r:self.assertEqual(r.status,400)
        async with self.client.get(self.url+'/') as r:
            self.assertEqual(r.status,200);html=await r.text();self.assertNotIn('mock-api',html);self.assertNotIn('id="review"',html)
        async with self.client.get(self.url+'/mock-api.js') as r:self.assertEqual(r.status,404)
        async with self.client.get(self.url+'/app.js') as r:self.assertNotIn('MockProviderTransport',await r.text())

    async def test_env_mode_and_two_accounts_independent(self):
        await self.add('one',key='key-one');await self.add('two',key='key-two')
        with patch.dict(os.environ,{'TM_TEST_API_KEY':'env-key'}):
            config=account('env',self.up_url+'/root');config.update(credential_mode='env',api_key_env='TM_TEST_API_KEY',api_key='')
            status,_=await self.api('/api/providers',config);self.assertEqual(status,200)
            for id,key in [('one','key-one'),('two','key-two'),('env','env-key')]:
                async with self.client.get(self.proxy_url+'/proxy/'+id+'/models') as r:await r.read()
                self.assertEqual(self.seen[-1][2]['Authorization'],'Bearer '+key)
        async with self.client.get(self.proxy_url+'/proxy/env/capture') as r:self.assertEqual(r.status,409)

    async def test_split_origin_and_catalog(self):
        async with self.client.get(self.url+'/proxy/one/capture') as r:self.assertEqual(r.status,404)
        async with self.client.get(self.proxy_url+'/api/session') as r:self.assertEqual(r.status,404)
        async with self.client.get(self.url+'/api/session',headers={'Origin':self.proxy_url}) as r:self.assertEqual(r.status,403)
        async with self.client.get(self.url+'/api/provider-profiles') as r:
            catalog=await r.json()
            self.assertEqual(catalog['gateway_url'],self.proxy_url)
            self.assertEqual(catalog['profiles']['claude']['auth_type'],'x_api_key')

    async def test_db_lock_does_not_stall_existing_stream(self):
        await self.add()
        async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'model':'test__stream','input':'hello'}) as response:
            self.assertEqual(await response.content.readexactly(13),b'data: first\n\n')
            lock=sqlite3.connect(self.path/'accounts.db')
            lock.execute('BEGIN IMMEDIATE')
            task=asyncio.create_task(self.api('/api/providers/enabled',{'id':'one','enabled':False}))
            try:
                await asyncio.sleep(.05)
                self.stream_release.set()
                self.assertEqual(await asyncio.wait_for(response.read(),.5),b'data: last\n\n')
                self.assertFalse(task.done())
            finally:lock.rollback();lock.close()
            self.assertEqual((await task)[0],200)

    async def test_name_only_preserves_probe_and_events_drop_safely(self):
        await self.add()
        command={'id':'one','request':{'method':'GET','path':'/models','headers':{},'body':''}}
        _,probe=await self.api('/api/providers/test',command)
        await self.api('/api/providers',dict(account('one',self.up_url+'/root',key=''),intent='update',name='renamed'))
        current=await self.app[REPO].call('snapshot')
        self.assertEqual(current['providers']['one']['probe'],probe)
        from provider.events import TransferEvents
        sink=TransferEvents(capacity=1)
        sink.publish({'status':200});sink.publish({'status':500})
        self.assertEqual(sink.dropped,1)
        async with self.client.get(self.proxy_url+'/proxy/one/capture?api_key=DO_NOT_RECORD') as r:await r.read()
        await asyncio.sleep(.01)
        events=list(self.app[GATEWAY][EVENTS].recent)
        self.assertTrue(events)
        self.assertNotIn('DO_NOT_RECORD',json.dumps(events))
        self.assertNotIn('test-key-A',json.dumps(events))

    async def test_check_cancel_releases_upstream_and_does_not_record_success(self):
        await self.add()
        _,etag=await self.app[REPO].call('view')
        from server import OPS
        task=asyncio.create_task(self.app[OPS].check({'id':'one','request':{'method':'POST','path':'/responses','headers':{'Content-Type':'application/json'},'body':json.dumps({'model':'test__cancel','input':'hi'})}},etag))
        for _ in range(100):
            if self.seen:break
            await asyncio.sleep(.01)
        task.cancel()
        with self.assertRaises(asyncio.CancelledError):await task
        await asyncio.wait_for(self.disconnected.wait(),1)
        self.assertIsNone((await self.app[REPO].call('snapshot'))['providers']['one']['probe'])


class MasterKeyTests(unittest.TestCase):
    def test_create_and_loss_detection(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'master.key'
            key=load_master_key(path)
            self.assertEqual(len(key),32);self.assertEqual(load_master_key(path),key)
            with self.assertRaises(RuntimeError):load_master_key(Path(directory)/'missing.key',True)


if __name__=='__main__':unittest.main()
