"""Disposable real service + local upstream for browser tests; never user data."""
import asyncio
import json
import os
import signal
import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from aiohttp import web
from server import create_app, GATEWAY, GATEWAY_URL


async def main():
    from test_service import listen
    async def echo(request):
        raw=await request.read()
        try:model=json.loads(raw).get('model','')
        except (ValueError,AttributeError):model=''
        if model=='test__slow':
            await asyncio.sleep(30)
        if model=='test__denied':
            return web.Response(status=401, text='rejected',headers={'x-request-id':'req-browser-401'})
        return web.Response(text='data: {"future":"ok"}\n\n',content_type='text/event-stream')
    upstream=web.Application()
    upstream.router.add_route('*','/{tail:.*}',echo)
    up_runner,up_url=await listen(upstream)
    with tempfile.TemporaryDirectory() as directory:
        app=create_app(Path(directory)/'accounts.db',os.urandom(32))
        proxy_runner,proxy_url=await listen(app[GATEWAY])
        app[GATEWAY_URL]=proxy_url
        runner,url=await listen(app)
        print(json.dumps({'url':url,'upstream':up_url,'gateway':proxy_url}),flush=True)
        stopped=asyncio.Event()
        for sig in (signal.SIGINT,signal.SIGTERM):asyncio.get_running_loop().add_signal_handler(sig,stopped.set)
        try:await stopped.wait()
        finally:await proxy_runner.cleanup();await runner.cleanup();await up_runner.cleanup()


asyncio.run(main())
