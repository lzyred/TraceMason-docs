"""Isolated real service and captured upstream used only by browser acceptance."""
import asyncio
import json
import os
import signal
import sys
import tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from aiohttp import web
from server import create_app, GATEWAY, GATEWAY_URL, REPO
from test_service import listen, account

async def main():
    captured=[]
    async def echo(request):
        raw=await request.read();captured.append(json.loads(raw) if raw else {})
        if captured[-1].get('model')=='delayed-native':await asyncio.sleep(.4)
        if captured[-1].get('model')=='denied-native':return web.json_response({'error':{'message':'fixture denied'}},status=401)
        response=web.StreamResponse(headers={'Content-Type':'text/event-stream'})
        await response.prepare(request)
        for word in ['请求已收到。','敏感内容已在发送前处理。']:
            payload=({'type':'response.output_text.delta','delta':word} if request.path.endswith('/responses') else
                     {'type':'content_block_delta','delta':{'type':'text_delta','text':word}}if request.path.endswith('/messages')else
                     {'choices':[{'delta':{'content':word}}]})
            packet=('data: '+json.dumps(payload,ensure_ascii=False)+'\r\n\r\n').encode()
            # Deliberately split UTF-8 characters and event lines across writes.
            for start in range(0,len(packet),7):
                await response.write(packet[start:start+7]);await asyncio.sleep(.001)
        return response
    async def evidence(request):return web.json_response({'captured':captured})
    upstream=web.Application();upstream.router.add_get('/evidence',evidence);upstream.router.add_post('/{tail:.*}',echo)
    up_runner,up_url=await listen(upstream)
    with tempfile.TemporaryDirectory()as directory:
        app=create_app(Path(directory)/'accounts.db',os.urandom(32))
        for kind in ['openai','deepseek','claude']:
            _,etag=await app[REPO].call('view');item=account(kind,up_url,kind,'browser-provider-'+kind);item['protocol']={'openai':'responses','deepseek':'chat_completions','claude':'messages'}[kind];await app[REPO].call('save',item,etag)
        proxy_runner,proxy_url=await listen(app[GATEWAY]);app[GATEWAY_URL]=proxy_url
        runner,url=await listen(app)
        print(json.dumps({'url':url,'upstream':up_url,'gateway':proxy_url}),flush=True)
        stopped=asyncio.Event()
        for sig in (signal.SIGINT,signal.SIGTERM):asyncio.get_running_loop().add_signal_handler(sig,stopped.set)
        try:await stopped.wait()
        finally:await proxy_runner.cleanup();await runner.cleanup();await up_runner.cleanup()

asyncio.run(main())
