"""Use a real local upstream; assertions inspect traffic, state and on-disk bytes."""
import asyncio
import copy
import json
import time
import unittest
from unittest.mock import patch
import test_service
from test_service import account
from privacy.detector import sanitize, inspect_request
from privacy.routes import PRIVACY
from errors import ServiceError


class DetectorTests(unittest.TestCase):
    def test_independent_examples_and_negative_controls(self):
        cases=[('请修复日志，密码为 Meow_82!，不要重复它。','Meow_82!'),
               ('DB_PASSWORD="hello world!"\nDB_HOST=10.20.30.40','hello world!'),
               ('ssh admin@10.2.3.4\n账号：admin\n验证码：123456','123456'),
               ('请联系 avery@example.net 获取材料','avery@example.net'),
               ('用户名=casey\n/home/casey/project/error.log','casey'),
               ('api\u200b_key=privateZeroWidthValue','privateZeroWidthValue'),
               ('ｐａｓｓｗｏｒｄ＝secretFullWidth','secretFullWidth')]
        for source,secret in cases:
            with self.subTest(source=source):
                safe,findings,mapping=sanitize(source)
                self.assertNotIn(secret,safe);self.assertTrue(findings)
        safe,_,mapping=sanitize('姓名：张三\n张三提交了错误')
        self.assertNotIn('张三',safe)
        self.assertEqual(sanitize('再次分析张三的记录',mapping)[0],'再次分析[姓名_1]的记录')
        self.assertEqual(sanitize('username=admin\nadministrator is a role')[0],'username=[账号_1]\nadministrator is a role')
        doc={'model':'future/provider-v999','messages':[{'role':'tool','tool_call_id':'call-88','content':'normal'}],
             'tools':[{'type':'function','function':{'name':'get_weather','parameters':{'type':'object','properties':{'city':{'type':'string'}}}}}], 'max_tokens':2048,'temperature':0.2}
        self.assertEqual(sanitize(doc)[0],doc)
        first,_,aliases=sanitize('姓名：张三\npassword=ExampleSecret93\nemail=casey@example.net')
        second,_,_=sanitize(first,aliases)
        self.assertEqual(second,first)
        self.assertNotIn('RealSecret928',sanitize('[password=RealSecret928_1]')[0])

    def test_structure_and_opaque_never_silently_rewritten(self):
        for doc in [{'model':'avery@example.net','input':'hello'}, {'input':[{'type':'input_image','image_url':'https://example.test/img'}]},
                    {'password':12345},{'input':'data:image/png;base64,aGVsbG8='},{'input':'A'*400},{'input':'\u202esecret'}, {'input':'-----BEGIN PRIVATE KEY-----\nincomplete-content'}, {'input':1e300,'n':float('inf')}]:
            with self.assertRaises(ServiceError):sanitize(doc)
        for raw in [b'{"input":"one","input":"two"}',b'{"input":"x","n":NaN}']:
            with self.assertRaises(ServiceError):inspect_request(raw,'/responses','POST',{'Content-Type':'application/json'})


class PrivacyTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = test_service.ServiceTests.asyncSetUp
    asyncTearDown = test_service.ServiceTests.asyncTearDown
    api = test_service.ServiceTests.api
    add = test_service.ServiceTests.add
    # Reuse fixture/helpers, not inherited v0.1.1 tests.
    async def new_task(self,kind='responses'):
        if not (await self.app[PRIVACY].accounts.call('snapshot'))['providers']:await self.add()
        status,t=await self.api('/api/privacy/tasks',{'destination_id':'one','model':'future-free-model','protocol':kind,'purpose':'排查登录失败，保留错误原因'})
        self.assertEqual(status,201,t);return t

    async def add_material(self,t,value,kind='config',origin='user'):
        status,t=await self.api('/api/privacy/tasks/'+t['id']+'/materials',{'expected_task_revision':t['revision'],'origin':origin,'kind_hint':kind,'text':value})
        self.assertEqual(status,200,t);return t

    async def build(self,t):
        status,m=await self.api('/api/privacy/tasks/'+t['id']+'/manifests',{'expected_task_revision':t['revision']})
        self.assertEqual(status,200,m);return m

    def release_body(self,t,m,key='one'):
        return {'expected_task_revision':t['revision'],'manifest_id':m['id'],'release_token':m['release_token'],'destination_id':t['destination_id'],'idempotency_key':key}

    async def consume(self,r):
        async with self.client.get(self.url+r['response_route'],headers={'X-TraceMason-Token':self.token}) as response:
            self.assertEqual(response.status,200);return await response.read()

    async def test_gateway_three_protocols_redaction_no_secret_in_database(self):
        await self.add()
        secrets=['PrivatePassword_93!','avery@private.example','13800138000','prod.db.internal','payloadKeyUnmarked']
        for path in ['/responses','/chat/completions','/messages']:
            text='password='+secrets[0]+'\nemail='+secrets[1]+'\n电话 '+secrets[2]+'\nDB_HOST='+secrets[3]+'\napi_key='+secrets[4]
            doc={'model':'arbitrary-version-123','input':text,'messages':[{'role':'user','content':text},{'role':'tool','content':'password=ToolSecret123','tool_call_id':'call-1'}], 'metadata':{'notes':'test-key-A'}}
            async with self.client.post(self.proxy_url+'/proxy/one'+path,json=doc,headers={'X-Custom':'PrivateHeaderSecret','Cookie':'secret=BrowserCookie'}) as r:self.assertEqual(r.status,200);await r.read()
            raw=self.seen[-1][3].decode()
            for secret in secrets+['ToolSecret123','test-key-A']:self.assertNotIn(secret,raw)
            self.assertNotIn('PrivateHeaderSecret',str(self.seen[-1][2]));self.assertNotIn('BrowserCookie',str(self.seen[-1][2]))
            self.assertEqual(json.loads(raw)['model'],'arbitrary-version-123')
        _,records=await self.api('/api/privacy/records',method='GET');self.assertEqual(records['total'],3)
        for f in self.path.iterdir():
            for secret in secrets+['ToolSecret123','PrivateHeaderSecret']:self.assertNotIn(secret.encode(),f.read_bytes())

    async def test_workbench_review_private_exclusion_bound_release_and_idempotency(self):
        t=await self.new_task();t=await self.add_material(t,'姓名：张三\n密码：TaskSecret728\n错误：拒绝连接','identity')
        t=await self.add_material(t,'-----BEGIN PRIVATE KEY-----\nPrivateKeyMaterial92\n-----END PRIVATE KEY-----','private')
        m=await self.build(t);self.assertEqual(m['state'],'needs_review');self.assertEqual(m['items'][2]['status'],'excluded')
        status,_=await self.api('/api/privacy/tasks/'+t['id']+'/releases',self.release_body(t,m));self.assertEqual(status,409);self.assertEqual(self.seen,[])
        row=m['items'][1];status,result=await self.api('/api/privacy/tasks/'+t['id']+'/reviews',{'expected_task_revision':t['revision'],'manifest_id':m['id'],'material_id':row['material_id'],'material_revision':row['material_revision'],'action':'approve_sanitized','sanitized_text':row['safe_preview']})
        self.assertEqual(status,200,result);_,t=await self.api('/api/privacy/tasks/'+t['id'],method='GET');m=await self.build(t);self.assertEqual(m['state'],'ready')
        body=self.release_body(t,m);status,r=await self.api('/api/privacy/tasks/'+t['id']+'/releases',body);self.assertEqual(status,202,r)
        await self.consume(r)
        status,again=await self.api('/api/privacy/tasks/'+t['id']+'/releases',body);self.assertEqual(status,202);self.assertEqual(r['release_id'],again['release_id']);self.assertEqual(len(self.seen),1)
        for secret in ['张三','TaskSecret728','PrivateKeyMaterial92']:self.assertNotIn(secret,self.seen[0][3].decode())
        self.assertIn('拒绝连接',self.seen[0][3].decode())
        self.assertIn('姓名：[姓名_1]',self.seen[0][3].decode())
        _,rows=await self.api('/api/privacy/records',method='GET')
        self.assertEqual(rows['items'][0]['risk_level'],'high')
        async with self.client.get(self.url+r['response_route'],headers={'X-TraceMason-Token':self.token}) as response:self.assertEqual(response.status,409)
        self.assertEqual(self.app[PRIVACY].release_info(r['release_id'],'local-administrator')['queue'].qsize(),0)

    async def test_invalidated_expired_destination_and_edited_account(self):
        t=await self.new_task();m=await self.build(t);old=self.release_body(t,m)
        t=await self.add_material(t,'more context')
        status,_=await self.api('/api/privacy/tasks/'+t['id']+'/releases',old);self.assertEqual(status,409)
        m=await self.build(t);self.app[PRIVACY].tasks[t['id']]['manifest']['deadline']=time.monotonic()-1
        status,_=await self.api('/api/privacy/tasks/'+t['id']+'/releases',self.release_body(t,m));self.assertEqual(status,410)
        m=await self.build(t);body=self.release_body(t,m);body['destination_id']='other'
        status,_=await self.api('/api/privacy/tasks/'+t['id']+'/releases',body);self.assertEqual(status,409)
        await self.api('/api/providers',dict(account('one',self.up_url+'/root',key='rotated-key'),intent='update'))
        status,_=await self.api('/api/privacy/tasks/'+t['id']+'/releases',self.release_body(t,m));self.assertEqual(status,409)
        self.assertEqual(self.seen,[])

    async def test_concurrent_release_exactly_once_and_unknown_formats(self):
        t=await self.new_task();m=await self.build(t)
        results=await asyncio.gather(*(self.api('/api/privacy/tasks/'+t['id']+'/releases',self.release_body(t,m,str(i)))for i in range(5)))
        self.assertEqual(sum(s==202 for s,r in results),1)
        for s,r in results:
            if s==202:await self.consume(r)
            else:self.assertEqual(s,409)
        self.assertEqual(len(self.seen),1)
        t=await self.add_material(t,'opaque','opaque');m=await self.build(t);self.assertEqual(m['state'],'blocked')
        status,_=await self.api('/api/privacy/tasks/'+t['id']+'/releases',self.release_body(t,m,'other'));self.assertEqual(status,409)

    async def test_gateway_failure_no_egress_and_ops_cannot_bypass(self):
        await self.add()
        for doc,path in [({'input':'hello'},'/responses?secret=QUERY_SECRET'),({'input':[{'type':'input_file','file_id':'file-1'}]},'/responses'),({'input':'new','previous_response_id':'resp-old'},'/responses'),({'input':'x'*70000},'/responses')]:
            async with self.client.post(self.proxy_url+'/proxy/one'+path,json=doc) as r:self.assertIn(r.status,[413,422])
        spec={'method':'POST','path':'/responses','headers':{'content-type':'application/json'},'body':json.dumps({'input':'password=ProbeSecret473'})}
        status,result=await self.api('/api/providers/test',{'id':'one','request':spec});self.assertEqual(status,200,result);self.assertEqual(len(self.seen),1);self.assertNotIn(b'ProbeSecret473',self.seen[0][3])
        status,_=await self.api('/api/providers/test',{'id':'one','request':dict(spec,path='/custom/SECRET_PATH')});self.assertEqual(status,422);self.assertEqual(len(self.seen),1)
        for f in self.path.iterdir():
            for value in [b'ProbeSecret473',b'QUERY_SECRET',b'SECRET_PATH']:self.assertNotIn(value,f.read_bytes())

    async def test_scanner_storage_and_capacity_fail_closed(self):
        await self.add();service=self.app[PRIVACY]
        async def denied(*args):raise ServiceError(503,'privacy_store_unavailable','unavailable')
        with patch.object(service.repo,'call',side_effect=denied):
            async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'input':'ordinary'})as r:self.assertEqual(r.status,503)
        service.jobs=8
        async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'input':'ordinary'})as r:self.assertEqual(r.status,503)
        service.jobs=0
        with patch('privacy.service.inspect_request',side_effect=ServiceError(503,'privacy_timeout','timeout')):
            async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'input':'ordinary'})as r:self.assertEqual(r.status,503)
        self.assertEqual(self.seen,[])

    async def test_private_get_auth_owner_and_deletion_exact_preview(self):
        await self.add()
        async with self.client.get(self.url+'/api/privacy/records')as r:self.assertEqual(r.status,403)
        t=await self.new_task()
        with self.assertRaises(ServiceError):self.app[PRIVACY].get(t['id'],'untrusted-principal')
        for i in range(2):
            async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'input':'password=DeleteSecret'})as r:await r.read()
        _,preview=await self.api('/api/privacy/records/deletion-preview',{'filters':{}});self.assertEqual(preview['count'],2)
        async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'input':'third'})as r:await r.read()
        status,result=await self.api('/api/privacy/records/deletion-confirm',preview);self.assertEqual(status,200);self.assertEqual(result['deleted_count'],2)
        _,remaining=await self.api('/api/privacy/records',method='GET');self.assertEqual(remaining['total'],1)
        status,_=await self.api('/api/privacy/records/deletion-confirm',preview);self.assertEqual(status,410)
        status,data=await self.api('/api/privacy/records/export',{'filters':{}});self.assertEqual(status,200);self.assertNotIn('DeleteSecret',json.dumps(data))
        await self.api('/api/privacy/tasks/'+t['id'],method='DELETE');self.assertNotIn(t['id'],self.app[PRIVACY].tasks)


    async def test_review_context_change_and_aliases_preserved_between_rounds(self):
        t=await self.new_task();t=await self.add_material(t,'姓名：张三\n错误：拒绝连接','identity');m=await self.build(t);row=m['items'][1]
        _,result=await self.api('/api/privacy/tasks/'+t['id']+'/reviews',{'expected_task_revision':t['revision'],'manifest_id':m['id'],'material_id':row['material_id'],'material_revision':row['material_revision'],'action':'approve_sanitized'})
        _,t=await self.api('/api/privacy/tasks/'+t['id'],method='GET');m=await self.build(t);self.assertEqual(m['state'],'ready')
        status,t=await self.api('/api/privacy/tasks/'+t['id'],{'expected_revision':t['revision'],'destination_id':'one','purpose':'继续分析张三的情况','next_round':True},method='PATCH');self.assertEqual(status,200)
        m=await self.build(t);self.assertEqual(m['state'],'needs_review');self.assertNotIn('张三',m['sanitized_preview'])
        self.assertIn('[姓名_1]',m['sanitized_preview'])

    async def test_direct_client_cancellation_and_stream_failure_recorded(self):
        await self.add()
        response=await self.client.post(self.proxy_url+'/proxy/one/responses',json={'model':'test__cancel','input':'password=CancelSecret'})
        self.assertEqual(await response.content.readexactly(5),b'first');response.close()
        await asyncio.wait_for(self.disconnected.wait(),2)
        for _ in range(30):
            _,rows=await self.api('/api/privacy/records',method='GET')
            if rows['items'][0]['forward_state']=='cancelled':break
            await asyncio.sleep(.01)
        self.assertEqual(rows['items'][0]['forward_state'],'cancelled')
        self.assertNotIn(b'CancelSecret',self.seen[0][3])

    async def test_capacity_ttl_transactional_update_and_audit_recovery(self):
        t=await self.new_task();service=self.app[PRIVACY];before=copy.deepcopy(service.tasks[t['id']])
        status,_=await self.api('/api/privacy/tasks/'+t['id'],{'expected_revision':t['revision'],'destination_id':'one','purpose':'changed','protocol':'invalid'},method='PATCH')
        self.assertEqual(status,422);self.assertEqual(service.tasks[t['id']]['purpose'],before['purpose']);self.assertEqual(service.tasks[t['id']]['revision'],before['revision'])
        service.tasks[t['id']]['expires']=time.monotonic()-1;service.purge();self.assertNotIn(t['id'],service.tasks)
        from privacy.repository import PrivacyRepository
        p=self.path/'recovery.sqlite3';repo=PrivacyRepository(p);rid=await repo.call('create','one','release',[],'gateway');await repo.close()
        repo=PrivacyRepository(p);records=await repo.call('list',{});self.assertEqual(records['items'][0]['forward_state'],'interrupted');await repo.close()

    async def test_runtime_responses_match_published_contract(self):
        spec=json.loads((__import__('pathlib').Path(__file__).resolve().parents[2]/'TraceMason-docs/design/v0.1.2/openapi.json').read_text())
        def valid(value,schema):
            if '$ref'in schema:schema=spec['components']['schemas'][schema['$ref'].split('/')[-1]]
            if 'anyOf'in schema:
                for choice in schema['anyOf']:
                    try:valid(value,choice);return
                    except AssertionError:pass
                self.fail('No schema alternative matched')
            typ=schema.get('type')
            if typ=='object':
                self.assertIsInstance(value,dict)
                for key in schema.get('required',[]):self.assertIn(key,value)
                if schema.get('additionalProperties')is False:self.assertFalse(set(value)-set(schema['properties']))
                for key,item in value.items():
                    if key in schema.get('properties',{}):valid(item,schema['properties'][key])
            elif typ=='array':
                self.assertIsInstance(value,list)
                for item in value:valid(item,schema['items'])
            elif typ=='string':self.assertIsInstance(value,str)
            elif typ=='integer':self.assertIs(type(value),int)
            elif typ=='number':self.assertIn(type(value),(int,float))
            elif typ=='boolean':self.assertIs(type(value),bool)
            elif typ=='null':self.assertIsNone(value)
            if 'enum'in schema:self.assertIn(value,schema['enum'])
            if 'const'in schema:self.assertEqual(value,schema['const'])
        async def check(path,kind,body=None,method=None):
            status,result=await self.api('/api/privacy'+path,body,method=method or ('POST'if body is not None else'GET'))
            self.assertLess(status,300,result);valid(result,spec['components']['schemas'][kind]);return result
        await check('/policy','Policy')
        t=await self.new_task();valid(t,spec['components']['schemas']['Task'])
        t=await self.add_material(t,'password=ContractCanary');m=await self.build(t);valid(m,spec['components']['schemas']['Manifest'])
        r=await check('/tasks/'+t['id']+'/releases','Release',self.release_body(t,m));await self.consume(r)
        await check('/releases/'+r['release_id'],'ReleaseStatus');await check('/records','RecordPage')
        await check('/records/export','Export',{'filters':{}})
        p=await check('/records/deletion-preview','DeletionPreview',{'filters':{}})
        await check('/records/deletion-confirm','Deleted',p)
        await check('/tasks/'+t['id'],'Closed',method='DELETE')

    async def test_workbench_three_protocol_envelopes(self):
        for protocol in ['responses','chat_completions','messages']:
            t=await self.new_task(protocol);m=await self.build(t)
            status,r=await self.api('/api/privacy/tasks/'+t['id']+'/releases',self.release_body(t,m,protocol));self.assertEqual(status,202,r);await self.consume(r)
            doc=json.loads(self.seen[-1][3]);self.assertEqual(doc['model'],'future-free-model')
            self.assertEqual(self.seen[-1][1],'/root'+{'responses':'/responses','chat_completions':'/chat/completions','messages':'/messages'}[protocol])
            if protocol=='messages':self.assertEqual(doc['max_tokens'],2048)
