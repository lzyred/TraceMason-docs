"""Synthetic cross-channel evaluation; deliberately not a population accuracy benchmark."""
import copy
import json
import unittest
from pathlib import Path
from privacy.detector import inspect_request
from errors import ServiceError
import test_service

CASES=json.loads(Path(__file__).with_name('privacy_cross_cases.json').read_text())
PROTOCOLS=[('openai','/responses'),('deepseek','/chat/completions'),('claude','/messages')]


def envelope(case,kind):
    value=copy.deepcopy(case['value']);mode=case['kind']
    doc={'model':'future-model-v999','stream':False,'temperature':0.25}
    if kind=='claude':doc['max_tokens']=512
    if mode=='blocks':content=[{'type':'input_text'if kind=='openai'else 'text','text':v}for v in value]
    else:content=value if mode=='text'else 'Check the weather'
    if kind=='openai':doc['input']=content
    else:doc['messages']=[{'role':'user','content':content}]
    if mode in ('schema','toolcall'):
        schema=value if mode=='schema'else {'type':'object','properties':{'city':{'type':'string'}}}
        if kind=='openai':doc['tools']=[{'type':'function','name':'get_weather','parameters':schema}]
        elif kind=='deepseek':doc['tools']=[{'type':'function','function':{'name':'get_weather','parameters':schema}}]
        else:doc['tools']=[{'name':'get_weather','description':'Check weather','input_schema':schema}]
    if mode=='toolcall':
        args=json.dumps(value,ensure_ascii=False)
        if kind=='openai':doc['input']=[{'type':'function_call','call_id':'call_1','name':'get_weather','arguments':args}]
        elif kind=='deepseek':doc['messages']=[{'role':'assistant','content':None,'tool_calls':[{'id':'call_1','type':'function','function':{'name':'get_weather','arguments':args}}]}]
        else:doc['messages']=[{'role':'assistant','content':[{'type':'tool_use','id':'tool_1','name':'get_weather','input':value}]}]
    return doc


def verify_payload(test,case,original,actual):
    text=json.dumps(actual,ensure_ascii=False)
    if case.get('unchanged'):test.assertEqual(actual,original,case['id'])
    for secret in case.get('secrets',[]):test.assertNotIn(secret,text,case['id'])
    for keep in case.get('keep',[]):test.assertIn(keep,text,case['id'])
    for field in ('model','stream','temperature','max_tokens'):
        if field in original:test.assertEqual(actual[field],original[field],case['id'])


class CrossChannelTests(unittest.IsolatedAsyncioTestCase):
    asyncSetUp=test_service.ServiceTests.asyncSetUp
    asyncTearDown=test_service.ServiceTests.asyncTearDown
    api=test_service.ServiceTests.api
    add=test_service.ServiceTests.add
    results=[]

    async def test_detector_trial_gateway_and_audit_agree(self):
        type(self).results=[]
        for kind,path in PROTOCOLS:
            await self.add(id=kind,kind=kind)
            for case in CASES:
                with self.subTest(provider=kind,case=case['id']):
                    doc=envelope(case,kind);raw=json.dumps(doc,ensure_ascii=False).encode();blocked=case.get('block',False)
                    before=len(self.seen)
                    if blocked:
                        with self.assertRaises(ServiceError)as caught:inspect_request(raw,path,'POST',{'Content-Type':'application/json'})
                        reason=caught.exception.code
                    else:
                        clean,findings,_=inspect_request(raw,path,'POST',{'Content-Type':'application/json'})
                        verify_payload(self,case,doc,json.loads(clean))
                        self.assertEqual(inspect_request(clean,path,'POST',{'Content-Type':'application/json'})[0],clean)
                    status,trial=await self.api('/api/privacy/policy/check',{'account_id':kind,'path':path,'request_json':raw.decode()})
                    self.assertEqual(status,200,trial);self.assertFalse(trial['sent']);self.assertEqual(len(self.seen),before)
                    async with self.client.post(self.proxy_url+'/proxy/'+kind+path,data=raw,headers={'Content-Type':'application/json'})as response:
                        status=response.status;body=await response.read();rid=response.headers.get('X-TraceMason-Request-ID');self.assertTrue(rid)
                    _,record=await self.api('/api/privacy/records/'+rid,method='GET')
                    self.assertEqual(record['policy_revision'],trial['policy_revision'])
                    if blocked:
                        self.assertGreaterEqual(status,400);self.assertEqual(len(self.seen),before);self.assertEqual(trial['reason_code'],reason);self.assertEqual(record['reason_code'],reason);self.assertEqual(record['forward_state'],'not_sent')
                    else:
                        self.assertEqual(status,200,body);self.assertEqual(len(self.seen),before+1)
                        actual=json.loads(self.seen[-1][3]);verify_payload(self,case,doc,actual)
                        self.assertEqual(actual,json.loads(trial['sanitized_request']));self.assertEqual(actual,json.loads(clean))
                        self.assertEqual(record['decision'],trial['decision']);self.assertEqual(record['forward_state'],'completed')
                        self.assertEqual(self.seen[-1][1],'/root'+path)
                        auth='x-api-key' if kind=='claude'else 'Authorization'
                        self.assertIn(auth,self.seen[-1][2])
                    for disk in self.path.iterdir():
                        for secret in case.get('secrets',[]):self.assertNotIn(secret.encode(),disk.read_bytes(),case['id'])
                    type(self).results.append({'id':case['id'],'provider':kind,'expected':'blocked'if blocked else 'unchanged'if case.get('unchanged')else 'redacted','result':'passed'})

    async def test_concurrent_account_isolation_and_fail_closed(self):
        import asyncio
        await self.add(id='automatic');await self.add(id='strict')
        status,_=await self.api('/api/privacy/policy/accounts/strict',{'expected_revision':1,'secrets_action':'block','identity_action':'block'},method='PUT');self.assertEqual(status,200)
        async def submit(i):
            account='strict'if i%2 else 'automatic'
            async with self.client.post(self.proxy_url+'/proxy/'+account+'/responses',json={'model':'future-concurrent','input':'password=ConcurrentPrivate%03d'%i})as r:
                body=await r.json(content_type=None);return account,r.status,r.headers.get('X-TraceMason-Request-ID'),body
        results=await asyncio.gather(*(submit(i)for i in range(32)))
        accepted=0;ids=set()
        for account,status,rid,body in results:
            self.assertTrue(rid);self.assertNotIn(rid,ids);ids.add(rid)
            self.assertIn(status,(200,409,503),body)
            if account=='strict':self.assertNotEqual(status,200)
            if status==200:accepted+=1
            _,row=await self.api('/api/privacy/records/'+rid,method='GET');self.assertEqual(row['destination_id'],account)
            if row['policy_revision']==0:self.assertEqual(row['reason_code'],'privacy_capacity')
            else:self.assertEqual(row['policy_revision'],2 if account=='strict'else 1)
            self.assertEqual(row['forward_state'],'completed'if status==200 else 'not_sent')
        self.assertGreater(accepted,0);self.assertEqual(len(self.seen),accepted)
        for request in self.seen:self.assertNotIn(b'ConcurrentPrivate',request[3])

    async def test_recovery_three_protocols_with_concurrent_claim(self):
        import asyncio
        for kind,path in PROTOCOLS:
            await self.add(id=kind,kind=kind)
            status,_=await self.api('/api/privacy/policy/accounts/'+kind,{'expected_revision':1,'secrets_action':'block','identity_action':'alias'},method='PUT');self.assertEqual(status,200)
            case=next(c for c in CASES if c['id']=='tool-arguments-sensitive');doc=envelope(case,kind)
            async with self.client.post(self.proxy_url+'/proxy/'+kind+path,json=doc)as r:
                self.assertEqual(r.status,409);rid=(await r.json())['error']['request_id']
            before=len(self.seen)
            outcomes=await asyncio.gather(self.api('/api/privacy/records/'+rid+'/recovery',{}),self.api('/api/privacy/records/'+rid+'/recovery',{}))
            self.assertEqual(sorted(status for status,_ in outcomes),[201,410])
            t=next(body for status,body in outcomes if status==201)
            status,m=await self.api('/api/privacy/tasks/'+t['id']+'/manifests',{'expected_task_revision':t['revision']});self.assertEqual(status,200,m)
            self.assertEqual(m['state'],'needs_review',m);item=m['items'][0]
            status,_=await self.api('/api/privacy/tasks/'+t['id']+'/reviews',{'expected_task_revision':t['revision'],'manifest_id':m['id'],'material_id':item['material_id'],'material_revision':item['material_revision'],'action':'approve_sanitized'})
            self.assertEqual(status,200)
            _,t=await self.api('/api/privacy/tasks/'+t['id'],method='GET')
            _,m=await self.api('/api/privacy/tasks/'+t['id']+'/manifests',{'expected_task_revision':t['revision']});self.assertEqual(m['state'],'ready',m)
            _,r=await self.api('/api/privacy/tasks/'+t['id']+'/releases',{'expected_task_revision':t['revision'],'manifest_id':m['id'],'release_token':m['release_token'],'destination_id':kind,'idempotency_key':'native-'+kind})
            async with self.client.get(self.url+r['response_route'],headers={'X-TraceMason-Token':self.token})as response:await response.read()
            self.assertEqual(len(self.seen),before+1);actual=json.loads(self.seen[-1][3]);verify_payload(self,case,doc,actual)
            self.assertEqual(self.seen[-1][1],'/root'+path)

    async def test_storage_failure_no_egress_or_false_record_claim(self):
        from unittest.mock import patch
        from privacy.routes import PRIVACY
        await self.add();repo=self.app[PRIVACY].repo;original=repo.call
        async def failed(method,*args):
            if method=='create':raise ServiceError(503,'privacy_store_unavailable','unavailable')
            return await original(method,*args)
        with patch.object(repo,'call',side_effect=failed):
            async with self.client.post(self.proxy_url+'/proxy/one/responses',json={'model':'future','input':'password=DiskFailureSecret715'})as r:
                self.assertEqual(r.status,503);body=await r.json();self.assertFalse(body['error']['record_saved']);self.assertFalse(body['error']['review_available']);self.assertTrue(body['error']['request_id'])
        self.assertEqual(self.seen,[])

    async def test_embedded_parser_boundaries_and_normalization_variants(self):
        import base64
        from privacy.detector import sanitize
        _,_,aliases=sanitize('username=CrossReclassified731')
        safe,_,aliases=sanitize('password=CrossReclassified731',aliases)
        self.assertNotIn('CrossReclassified731',safe);self.assertNotIn('CrossReclassified731',aliases)
        for field in ['api_key','API_KEY','apiKey','API\u200b_KEY','ａｐｉ＿ｋｅｙ']:
            for wrapper in [lambda x:x,lambda x:json.dumps(x,ensure_ascii=False)]:
                doc={'input':wrapper({field:'InvariantSecret731'})}
                # Structured input belongs inside a text item for a real protocol envelope.
                if isinstance(doc['input'],dict):doc={'input':'Inspect','metadata':doc['input']}
                clean,_,_=inspect_request(json.dumps(doc).encode(),'/responses','POST',{'Content-Type':'application/json'})
                self.assertNotIn(b'InvariantSecret731',clean)
        for content in ['{"phone":"020-98765432","phone":"020-12345678"}',base64.b64encode(b'password=abc').decode()]:
            with self.assertRaises(ServiceError):inspect_request(json.dumps({'input':content}).encode(),'/responses','POST',{'Content-Type':'application/json'})
        nested={'phone':'020-98765432'}
        for _ in range(35):nested={'payload':nested}
        nested=json.dumps(nested)
        with self.assertRaises(ServiceError):inspect_request(json.dumps({'input':nested}).encode(),'/responses','POST',{'Content-Type':'application/json'})
