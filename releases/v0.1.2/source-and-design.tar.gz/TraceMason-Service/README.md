# TraceMason v0.1.2

本机 API 接入与隐私外发防护。OpenAI/Codex API、DeepSeek、Claude；不做订阅转换。

```sh
docker compose up -d --build --wait
```

[容器部署与持久化](docs/container.html)。本机开发方式：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python server.py
```

控制台：<http://127.0.0.1:8766>。在「API 接入」添加账号后，客户端使用 `http://127.0.0.1:8768/proxy/{账号标识}/` 加上游相对路径；模型名和请求正文由客户端指定。

```sh
.venv/bin/python -m unittest discover -s tests -v
node scripts/browser-check.mjs
node scripts/browser-privacy-check.mjs
```

[运行与实现说明](docs/implementation.html) · [评审设计入口](docs/design-entry.html)

防护工作台：<http://127.0.0.1:8766/privacy.html>。支持三种文本模型 JSON 协议；不支持的上传、WebSocket、压缩正文、远程附件直接拒绝。账号可配置秘密移除/拦截、身份别名/拦截；策略试检不调用模型。外发记录展示原因、规则与实际状态；完成检查的被拦截请求可领取脱敏候选重新确认，不自动重试原客户端。固定本地规则不保证检出未知秘密或未标注自然语言身份。

[隐私服务与范围](docs/privacy.html) · [完整架构与接口](../TraceMason-docs/design/v0.1.2/index.html)

[安全加固闭环与数据生命周期](../TraceMason-docs/design/v0.1.2/hardening.html)

[可靠性交叉验证与定版门槛](../TraceMason-docs/design/v0.1.2/reliability.html)。复跑：`.venv/bin/python scripts/verify-reliability.py --output /tmp/tracemason-reliability.json`。v0.1.2 已按用户决定定版；真实厂商与代表性隐私语料未验收，作为已知边界保留。

[定版记录与源码基线](../TraceMason-docs/design/v0.1.2/release.html) · [下一版 C/S 交互规划](../TraceMason-docs/design/v0.1.3/index.html)
