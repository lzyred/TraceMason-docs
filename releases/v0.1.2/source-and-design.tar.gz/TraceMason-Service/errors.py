class ServiceError(Exception):
    def __init__(self, status, code, message, field=None):
        self.status, self.code, self.message, self.field = status, code, message, field
        super().__init__(message)

    def body(self):
        return {'error': {k: v for k, v in {
            'code': self.code, 'message': self.message, 'field': self.field,
            'request_id':getattr(self,'request_id',None),
            'review_available':getattr(self,'review_available',None),
            'record_saved':getattr(self,'record_saved',None)
        }.items() if v is not None}}
