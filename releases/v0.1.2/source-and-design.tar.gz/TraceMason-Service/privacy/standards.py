"""Closed, versioned vocabulary: never persist detector/user-controlled reason strings."""
POLICY_VERSION = 2
RULESET = 'local-context-3'
REASONS = {
 'privacy_cross_block':'敏感值跨多个内容块，需整理为完整文本后重检',
 'invalid_path':'上游路径无效，未外发',
 'purpose_or_semantics':'用途或语义需要限定确认',
 'uninspectable':'材料无法检查',
 'checked': '已完成支持范围内的检查',
 'redacted': '已替换敏感内容，实际交付以发送状态为准',
 'privacy_secret_policy': '账号策略要求拦截含认证秘密的请求',
 'privacy_identity_policy': '账号策略要求拦截含身份或环境信息的请求',
 'privacy_review_required': '内容不能完整检查，需整理或排除',
 'privacy_encoded_content': '编码内容包含敏感线索，需解码整理后检查',
 'privacy_remote_tool': '远程执行工具可能绕过本机检查，不允许委托外发',
 'privacy_remote_history_unavailable': '远程历史内容无法检查',
 'privacy_sensitive_structure': '结构标识包含敏感信息，不能安全替换',
 'privacy_typed_sensitive_field': '敏感数值字段需要整理，不能擅改类型',
 'privacy_invalid_json': 'JSON无效、重复字段或非法编码',
 'privacy_invalid_request': '请求结构无效',
 'privacy_uninspectable_route': '路径或查询参数不在可检查范围',
 'privacy_unsupported_protocol': '协议或路径不受支持',
 'privacy_unsupported_encoding': '压缩正文不能完整检查',
 'privacy_unsupported_content_type': '正文不是支持的文本JSON',
 'privacy_unsafe_header': '协议请求头包含无法安全传递的内容',
 'privacy_too_large': '内容超过64KiB检查上限',
 'privacy_complexity_limit': '内容结构超过检查容量',
 'privacy_alias_capacity': '任务身份映射超过容量',
 'privacy_timeout': '检查超时，未外发',
 'privacy_body_timeout': '读取正文超时，未外发',
 'privacy_capacity': '检查容量已满，未外发',
 'privacy_store_unavailable': '记录存储失败，未外发',
 'privacy_changed': '账号、策略或内容已变化，需重新检查',
 'privacy_cancelled': '请求已取消',
 'privacy_internal_error': '检查服务异常，未外发',
 'privacy_residual_secret': '替换后仍有已识别敏感内容',
 'legacy': '升级前记录，未保存具体判定依据',
 'manual_review': '材料需要限定确认',
}
RULE_NAMES = {
 'sensitive_field':'认证秘密字段', 'identity_field':'身份字段', 'environment_field':'环境字段',
 'provider_secret_in_body':'配置的上游密钥出现在正文', 'task_alias':'同任务已知身份',
 'private_material':'整份私钥材料', 'policy_secret':'认证秘密拦截策略', 'policy_identity':'身份信息拦截策略',
}
for label in ('认证秘密','连接凭据','邮箱','手机号','身份证','姓名','地址','本机用户','账号','服务器','SSH登录','会话凭据','JWT','身份描述'):
    RULE_NAMES['local_'+label]=label+'格式或上下文'


def policy_action(findings, policy):
    if policy['secrets_action']=='block' and any(f['category']=='secret' for f in findings):return 'privacy_secret_policy'
    if policy['identity_action']=='block' and any(f['category'] in ('identity','environment') for f in findings):return 'privacy_identity_policy'
    return None


def policy_defaults():return dict(revision=1,secrets_action='redact',identity_action='alias')
