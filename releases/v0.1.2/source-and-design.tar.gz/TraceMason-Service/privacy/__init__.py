"""Local, pre-egress privacy enforcement. Never send original input to a detector."""
