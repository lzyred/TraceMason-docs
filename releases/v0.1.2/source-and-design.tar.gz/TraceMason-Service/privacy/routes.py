"""Same-origin, authenticated local administration API. No remote principals implied."""
import asyncio
import json
import secrets
import time
from datetime import datetime
from aiohttp import web
from privacy.detector import strict_json
from privacy.service import error, ident, integer, text

PRIVACY = web.AppKey('privacy', object)
OWNER = 'local-administrator'

async def command(request):
    if request.content_type != 'application/json': error('privacy_invalid_content_type',415)
    body = strict_json(await request.read())
    if not isinstance(body,dict): error('privacy_invalid_parameter',400)
    return body


def filters(raw):
    if not isinstance(raw,dict) or set(raw)-{'destination_id','decision','since','until'}: error('privacy_invalid_parameter',400)
    out={}
    for k,v in raw.items():
        if not v:continue
        if k=='destination_id':out[k]=text(v,64)
        elif k=='decision':
            if v not in ('blocked','redacted','release'):error('privacy_invalid_parameter',400)
            out[k]=v
        else:
            try:
                d=datetime.fromisoformat(v.replace('Z','+00:00'))
                if d.tzinfo is None:raise ValueError()
                out[k]=d.timestamp()
            except (ValueError,TypeError,AttributeError,OverflowError):error('privacy_invalid_parameter',400)
    if out.get('since',0)>=out.get('until',float('inf')):error('privacy_invalid_parameter',400)
    return out

async def policy(request):return web.json_response(request.app[PRIVACY].policy())

async def account_policy(request):
    s=request.app[PRIVACY];aid=request.match_info['account_id']
    value=await s.account_policy(aid) if request.method=='GET'else await s.save_policy(aid,await command(request))
    return web.json_response(value)

async def policy_check(request):return web.json_response(await request.app[PRIVACY].trial(await command(request)))

async def record_detail(request):return web.json_response(await request.app[PRIVACY].record_detail(request.match_info['record_id']))

async def recover(request):
    await command(request)
    return web.json_response(await request.app[PRIVACY].recover(request.match_info['record_id'],OWNER),status=201)

async def task(request):
    service=request.app[PRIVACY];tid=request.match_info.get('task_id')
    if request.method=='POST':result=await service.create(OWNER,await command(request))
    elif request.method=='GET':result=service.public(service.get(tid,OWNER))
    elif request.method=='PATCH':result=await service.update(tid,OWNER,await command(request))
    else:result=service.end(tid,OWNER)
    return web.json_response(result,status=201 if request.method=='POST' else 200)

async def material(request):
    s=request.app[PRIVACY];tid=request.match_info['task_id'];body=await command(request)
    if request.method=='POST':result=s.add(tid,OWNER,body)
    else:result=s.material(tid,request.match_info['material_id'],OWNER,body)
    return web.json_response(result)

async def manifest(request):
    return web.json_response(await request.app[PRIVACY].build(request.match_info['task_id'],OWNER,await command(request)))

async def review(request):
    return web.json_response(await request.app[PRIVACY].review(request.match_info['task_id'],OWNER,await command(request)))

async def release(request):
    return web.json_response(await request.app[PRIVACY].release(request.match_info['task_id'],OWNER,await command(request)),status=202)

async def release_status(request):
    return web.json_response(request.app[PRIVACY].release_info(request.match_info['release_id'],OWNER)['public'])

async def response(request):
    r=request.app[PRIVACY].release_info(request.match_info['release_id'],OWNER)
    if r['claimed']:error('privacy_response_already_consumed',409)
    r['claimed']=True;r['subscriber'].set()
    stream=None
    try:
        await asyncio.wait_for(r['started'].wait(),30)
        if r['status'] is None:error('privacy_upstream_unavailable',502)
        # Raw upstream headers/cookies must not control the management origin.
        headers={'Cache-Control':'no-store','Content-Type':r['headers'].get('Content-Type','application/octet-stream'),
                 'X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox"}
        if r['headers'].get('Content-Encoding'):headers['Content-Encoding']=r['headers']['Content-Encoding']
        stream=web.StreamResponse(status=r['status'],headers=headers)
        await stream.prepare(request)
        while not r['done'] or not r['queue'].empty():
            try:chunk=await asyncio.wait_for(r['queue'].get(),0.25)
            except asyncio.TimeoutError:continue
            await stream.write(chunk)
        if r['public']['forward_state']in ('failed','cancelled') and r['status']<400:
            if request.transport:request.transport.close()
        else:await stream.write_eof()
        return stream
    except (ConnectionError,asyncio.TimeoutError):
        if stream and stream.prepared:
            if request.transport:request.transport.close()
            return stream
        error('privacy_upstream_unavailable',502)
    finally:
        if not r['job'].done():r['job'].cancel()
        await asyncio.gather(r['job'],return_exceptions=True)
        while not r['queue'].empty():r['queue'].get_nowait()
        r['headers']={}

async def records(request):
    q=dict(request.query)
    try:page=int(q.pop('page','1'));size=int(q.pop('page_size','20'))
    except ValueError:error('privacy_invalid_parameter',400)
    integer(page,1,1000000);integer(size,1,100)
    return web.json_response(await request.app[PRIVACY].repo.call('list',filters(q),page,size))

async def export(request):
    s=request.app[PRIVACY];body=await command(request)
    result=await s.repo.call('list',filters(body.get('filters',{})),1,10001)
    if result['total']>10000:error('privacy_export_limit',413)
    data=json.dumps({'records':result['items']},ensure_ascii=False).encode()
    if len(data)>20*1024*1024:error('privacy_export_limit',413)
    return web.Response(body=data,content_type='application/json',headers={'Content-Disposition':'attachment; filename="privacy-records.json"'})

async def deletion_preview(request):
    s=request.app[PRIVACY];s.purge();body=await command(request)
    if len(s.deletions)>=32:error('privacy_capacity',503)
    ids=await s.repo.call('preview',filters(body.get('filters',{})))
    pid=ident();nonce=secrets.token_urlsafe(32)
    s.deletions[pid]=dict(ids=ids,nonce=nonce,owner=OWNER,expires=time.monotonic()+60)
    return web.json_response(dict(preview_id=pid,confirmation_token=nonce,count=len(ids),expires_in=60))

async def deletion_confirm(request):
    s=request.app[PRIVACY];s.purge();body=await command(request);p=s.deletions.get(text(body.get('preview_id'),64))
    if not p:error('privacy_expired',410)
    if p['owner']!=OWNER or not isinstance(body.get('confirmation_token'),str) or not secrets.compare_digest(p['nonce'],body['confirmation_token']):error('privacy_forbidden',403)
    del s.deletions[body['preview_id']]
    for rid in p['ids']:s.cases.pop(rid,None)
    return web.json_response({'deleted_count':await s.repo.call('delete',p['ids'])})


def install(app,service):
    app[PRIVACY]=service
    for method,path,handler in [
        ('GET','/policy',policy),('GET','/policy/accounts/{account_id}',account_policy),('PUT','/policy/accounts/{account_id}',account_policy),('POST','/policy/check',policy_check),
        ('GET','/records/{record_id}',record_detail),('POST','/records/{record_id}/recovery',recover),('POST','/tasks',task),('GET','/tasks/{task_id}',task),
        ('PATCH','/tasks/{task_id}',task),('DELETE','/tasks/{task_id}',task),
        ('POST','/tasks/{task_id}/materials',material),('PATCH','/tasks/{task_id}/materials/{material_id}',material),
        ('POST','/tasks/{task_id}/manifests',manifest),('POST','/tasks/{task_id}/reviews',review),
        ('POST','/tasks/{task_id}/releases',release),('GET','/releases/{release_id}',release_status),
        ('GET','/releases/{release_id}/response',response),('GET','/records',records),
        ('POST','/records/export',export),('POST','/records/deletion-preview',deletion_preview),
        ('POST','/records/deletion-confirm',deletion_confirm)]:app.router.add_route(method,'/api/privacy'+path,handler)
