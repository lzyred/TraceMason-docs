"""Bounded in-memory task manifests and the shared pre-egress authorization gate."""
import asyncio
import copy
import json
import secrets
import time
import uuid
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from errors import ServiceError
from privacy.detector import sanitize, inspect_request, MAX_BYTES, RULESET, fail
from privacy.repository import PrivacyRepository
from privacy.detector import strict_json
from privacy.standards import POLICY_VERSION, REASONS, RULE_NAMES, policy_action


def ident(): return uuid.uuid4().hex

def error(code, status=409):
    raise ServiceError(status, code, {
        'privacy_changed': '任务、账号或清单已变化，请重新生成外发清单。',
        'privacy_expired': '任务或清单已过期，请重新检查。',
        'privacy_review_required': '尚有需要处理的材料，未允许外发。',
        'privacy_capacity': '本机防护容量已满，请稍后重试。',
    }.get(code, '防护请求状态无效，请刷新后重试。'))


def integer(value, lo=1, hi=100000):
    if type(value) is not int or not lo <= value <= hi: error('privacy_invalid_parameter',400)
    return value


def text(value, maximum=4000, allow_empty=False):
    if not isinstance(value, str) or len(value.encode('utf-8'))>maximum or (not allow_empty and not value.strip()):
        error('privacy_invalid_parameter',400)
    return value


@dataclass(frozen=True)
class Approved:
    body: bytes
    headers: dict
    record_id: str
    path: str
    account_id: str
    config_revision: int
    seal: object
    policy_revision: int = 1


class PrivacyService:
    def __init__(self, accounts, path):
        self.accounts = accounts
        self.repo = PrivacyRepository(Path(path).with_name('privacy.sqlite3'))
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix='privacy-scan')
        self.jobs = 0
        self.seal = object()
        self.tasks, self.releases, self.deletions, self.cases = {}, {}, {}, {}
        self.maintenance = None
        self.transport = None
        self.active_buffers = 0

    async def start(self): self.maintenance=asyncio.create_task(self._maintenance())

    async def _maintenance(self):
        while True:
            await asyncio.sleep(15)
            self.purge()
            try: await self.repo.call('purge')
            except ServiceError: pass

    def purge(self):
        now=time.monotonic()
        for key,t in list(self.tasks.items()):
            if now>=t['expires'] or now>=t['created']+7200:
                self._end(t);self.tasks.pop(key,None)
        for key,r in list(self.releases.items()):
            if now>=r['created']+1800 and (r.get('job') is None or r['job'].done()): self.releases.pop(key,None)
        for key,c in list(self.cases.items()):
            if now>=c['expires']:self.cases.pop(key,None)
        for key,p in list(self.deletions.items()):
            if now>=p['expires']:self.deletions.pop(key,None)

    async def scan(self, fn, *args):
        if self.jobs>=8: error('privacy_capacity',503)
        self.jobs+=1
        future=asyncio.get_running_loop().run_in_executor(self.pool,fn,*args)
        # Timed-out/cancelled scans retain their capacity slot until actually done.
        future.add_done_callback(lambda _:setattr(self,'jobs',self.jobs-1))
        try: return await asyncio.wait_for(asyncio.shield(future),1.5)
        except asyncio.TimeoutError: fail('privacy_timeout',503)

    async def prepare(self, account, method, path, headers, data, source='gateway'):
        request_id=ident();buffered=False;policy=None;findings=[];candidate=None
        try:
            if self.active_buffers>=16:error('privacy_capacity',503)
            self.active_buffers+=1;buffered=True
            from provider.transport import target_url
            target_url(account['base_url'],path)
            policy=await self.repo.call('policy',account['id'])
            if isinstance(data,(bytes,bytearray)):raw=bytes(data)
            elif data is None:raw=b''
            else:
                async def collect():
                    raw=bytearray()
                    async for chunk in data:
                        if len(raw)+len(chunk)>MAX_BYTES:fail('privacy_too_large',413)
                        raw.extend(chunk)
                    return bytes(raw)
                try:raw=await asyncio.wait_for(collect(),15)
                except asyncio.TimeoutError:fail('privacy_body_timeout',408)
            clean,findings,safe_headers=await self.scan(inspect_request,raw,path,method,headers,(account['key'],))
            reason=policy_action(findings,policy)
            if reason:
                candidate=(clean,safe_headers)
                fail(reason,409)
            record=await self.repo.call('create',account['id'],'redacted' if findings else 'release',findings,source,1,0,0,
                       {'id':request_id,'policy_revision':policy['revision']})
            return Approved(clean,safe_headers,record,path,account['id'],account['config_revision'],self.seal,policy['revision'])
        except (ServiceError,asyncio.CancelledError) as exc:
            reason=getattr(exc,'code','privacy_cancelled')
            saved=False
            try:
                await self.repo.call('create',account['id'],'blocked',findings,source,1,0,0,
                     {'id':request_id,'reason_code':reason,'policy_revision':policy['revision'] if policy else 0})
                saved=True
            except ServiceError:pass
            available=False
            if saved and candidate is not None:
                self.purge()
                model=strict_json(candidate[0]).get('model')
                if len(self.cases)<16 and isinstance(model,str) and model.strip() and len(model.encode('utf-8'))<=512:
                    self.cases[request_id]=dict(body=candidate[0],headers=candidate[1],path=path,
                        account_id=account['id'],config_revision=account['config_revision'],findings=findings,
                        expires=time.monotonic()+600,claimed=False)
                    available=True
            if isinstance(exc,ServiceError):
                exc.request_id=request_id;exc.review_available=available;exc.record_saved=saved
            raise
        except Exception:
            exc=ServiceError(503,'privacy_internal_error','检查服务异常，原文未外发。');exc.request_id=request_id;exc.review_available=False
            try:
                await self.repo.call('create',account['id'],'blocked',[],source,1,0,0,{'id':request_id,'reason_code':exc.code,'policy_revision':policy['revision'] if policy else 0})
                exc.record_saved=True
            except ServiceError:exc.record_saved=False
            raise exc from None
        finally:
            if buffered:self.active_buffers-=1

    async def account_policy(self,account_id):
        await self.accounts.call('resolve',account_id)
        value=await self.repo.call('policy',account_id)
        return dict(value,account_id=account_id,history=await self.repo.call('policy_history',account_id))

    async def save_policy(self,account_id,body):
        await self.accounts.call('resolve',account_id)
        value=await self.repo.call('save_policy',account_id,body)
        for t in self.tasks.values():
            if t['destination']==account_id:self.change(t)
        return dict(value,account_id=account_id,history=await self.repo.call('policy_history',account_id))

    async def trial(self,body):
        account=await self.accounts.call('resolve',text(body.get('account_id'),64))
        policy=await self.repo.call('policy',account['id'])
        path=text(body.get('path'),64);raw=text(body.get('request_json'),MAX_BYTES).encode()
        try:
            clean,findings,_=await self.scan(inspect_request,raw,path,'POST',{'Content-Type':'application/json'},(account['key'],))
            reason=policy_action(findings,policy)
            return dict(decision='blocked' if reason else 'redacted' if findings else 'release',reason_code=reason or ('redacted' if findings else 'checked'),
                findings=findings,sanitized_request=clean.decode(),policy_revision=policy['revision'],ruleset_version=RULESET,sent=False)
        except ServiceError as exc:
            return dict(decision='blocked',reason_code=exc.code,findings=[],sanitized_request=None,policy_revision=policy['revision'],ruleset_version=RULESET,sent=False)

    async def record_detail(self,record_id):
        self.purge();result=await self.repo.call('detail',record_id)
        c=self.cases.get(record_id)
        result['review_available']=bool(c and not c['claimed'])
        result['review_expires_in']=max(0,int(c['expires']-time.monotonic()))if c else 0
        return result

    async def recover(self,record_id,owner):
        self.purge();c=self.cases.get(record_id)
        if not c or c['claimed']:error('privacy_recovery_unavailable',410)
        c['claimed']=True;created=None
        try:
            account=await self.accounts.call('resolve',c['account_id'])
            if account['config_revision']!=c['config_revision']:error('privacy_changed')
            doc=strict_json(c['body']);protocol='responses' if c['path'].endswith('/responses')else 'messages'if c['path'].endswith('/messages')else 'chat_completions'
            created=await self.create(owner,dict(destination_id=c['account_id'],model=doc.get('model'),protocol=protocol,purpose='核对被拦截请求的脱敏候选'))
            t=self.get(created['id'],owner)
            self.add(t['id'],owner,dict(expected_task_revision=t['revision'],origin='user',kind_hint='code',text=c['body'].decode()))
            t['native_request']=True;t['native_path']=c['path'];t['native_headers']=c['headers'];t['origin_record_id']=record_id
            t['sources'][0]['reviewed_findings']=c['findings']
            return dict(self.public(t),candidate=c['body'].decode(),purpose=t['purpose'])
        except BaseException:
            if created:self.tasks.pop(created['id'],None)
            c['claimed']=False;raise
        finally:
            if c['claimed']:self.cases.pop(record_id,None)

    def verify(self, approved, account):
        if not isinstance(approved,Approved) or approved.seal is not self.seal or approved.account_id!=account['id'] or approved.config_revision!=account['config_revision']:
            error('privacy_changed')

    async def state(self,record,status):
        try:await self.repo.call('state',record,status)
        except ServiceError:pass # Existing authorized stream must not replay on telemetry failure.

    def policy(self):
        return dict(revision=POLICY_VERSION,credential_original_release_allowed=False,identity_action='task_alias',
            unknown_action='review_or_exclude',ruleset_version=RULESET,supported_extractors=['UTF-8 text','model JSON'],
            task_ttl_seconds=1800,manifest_ttl_seconds=120,max_materials=16,max_material_bytes=MAX_BYTES,
            record_retention_days=30,recognizer_scope='字段、格式、身份上下文与已知编码线索识别；不保证检出所有未知秘密或自然语言身份。',rules=[dict(id=k,name=v)for k,v in RULE_NAMES.items()],reason_catalog=REASONS)

    def get(self, task_id, owner):
        self.purge();t=self.tasks.get(task_id)
        if not t: error('privacy_expired',410)
        if t['owner']!=owner:error('privacy_forbidden',403)
        return t

    def public(self,t):
        return dict(id=t['id'],revision=t['revision'],round=t['round'],destination_id=t['destination'],
            model=t['model'],protocol=t['protocol'],native_request=t.get('native_request',False),origin_record_id=t.get('origin_record_id'),expires_in=max(0,int(t['expires']-time.monotonic())),
            state='ready' if t.get('manifest',{}).get('state')=='ready' else 'collecting',
            materials=[dict(id=s['id'],index=i+1,origin=s['origin'],kind_hint=s['kind'],revision=s['revision'],
                       state='excluded' if s['excluded'] else 'unclassified',coverage='unsupported' if s['kind']=='opaque' else 'unknown') for i,s in enumerate(t['sources'])])

    def change(self,t):
        t['revision']+=1;t['expires']=time.monotonic()+1800;t.pop('manifest',None)

    def expect(self,t,revision):
        if integer(revision)!=t['revision']:error('privacy_changed')

    async def create(self,owner,body):
        self.purge()
        if len(self.tasks)>=32 or sum(t['owner']==owner for t in self.tasks.values())>=16:error('privacy_capacity',503)
        dest=text(body.get('destination_id'),64);account=await self.accounts.call('resolve',dest)
        protocol=body.get('protocol',account['protocol'])
        if protocol not in ('responses','chat_completions','messages'):error('privacy_protocol',422)
        t=dict(id=ident(),owner=owner,destination=dest,purpose=text(body.get('purpose')),model=text(body.get('model'),512),
               protocol=protocol,revision=1,round=1,sources=[],aliases={},created=time.monotonic(),expires=time.monotonic()+1800)
        if len(self.tasks)>=32 or sum(x['owner']==owner for x in self.tasks.values())>=16:error('privacy_capacity',503)
        self._memory(t,additional=True);self.tasks[t['id']]=t
        return self.public(t)

    def _memory(self,candidate,additional=False):
        def size(t):return len(t['purpose'].encode())+sum(len(s['text'].encode())for s in t['sources'])
        if size(candidate)>1024*1024:error('privacy_capacity',413)
        total=sum(size(t)for t in self.tasks.values()if t['id']!=candidate['id'])+size(candidate)
        if total>32*1024*1024:error('privacy_capacity',503)

    async def update(self,task_id,owner,body):
        t=self.get(task_id,owner);self.expect(t,body.get('expected_revision'))
        if t.get('native_request') and (body.get('destination_id')!=t['destination'] or body.get('protocol',t['protocol'])!=t['protocol'] or body.get('model',t['model'])!=t['model']):error('privacy_changed')
        dest=text(body.get('destination_id'),64);await self.accounts.call('resolve',dest)
        self.expect(t,body.get('expected_revision'))
        purpose=text(body.get('purpose'));model=text(body.get('model',t['model']),512)
        p=body.get('protocol',t['protocol'])
        if p not in ('responses','chat_completions','messages'):error('privacy_protocol',422)
        self._memory(dict(t,purpose=purpose))
        if dest!=t['destination']:t['aliases'].clear()
        if dest!=t['destination'] or purpose!=t['purpose'] or model!=t['model'] or p!=t['protocol']:
            for source in t['sources']:source['confirmed']=False
        t.update(destination=dest,purpose=purpose,model=model,protocol=p)
        if body.get('next_round') is True:
            t['round']+=1
            for s in t['sources']:s['confirmed']=False
        self.change(t);return self.public(t)

    def add(self,task_id,owner,body):
        t=self.get(task_id,owner);self.expect(t,body.get('expected_task_revision'))
        if t.get('native_request'):error('privacy_native_single_material',400)
        if len(t['sources'])>=16:error('privacy_capacity',413)
        content=text(body.get('text'),MAX_BYTES,True);origin=body.get('origin');kind=body.get('kind_hint')
        if origin not in ('user','tool','upload') or kind not in ('text','config','log','code','identity','private','unknown','opaque'):error('privacy_invalid_parameter',400)
        # Source labels can increase caution, never authorize credentials or opaque bytes.
        if '\x00' in content or re_binary(content):kind='opaque'
        if '-----BEGIN ' in content and 'PRIVATE KEY-----'in content:kind='private'
        s=dict(id=ident(),text=content,kind=kind,origin=origin,excluded=False,confirmed=False,revision=1)
        draft=dict(t,sources=t['sources']+[s]);self._memory(draft)
        t['sources'].append(s);self.change(t);return self.public(t)

    def material(self,task_id,material_id,owner,body):
        t=self.get(task_id,owner);self.expect(t,body.get('expected_task_revision'))
        s=next((s for s in t['sources']if s['id']==material_id),None)
        if not s:error('privacy_material_not_found',404)
        action=body.get('action')
        if action=='exclude':s['excluded']=True
        elif action=='rescan':
            value=text(body.get('replacement_text'),MAX_BYTES,True)
            draft=copy.deepcopy(t);next(x for x in draft['sources']if x['id']==material_id)['text']=value;self._memory(draft)
            s['text']=value;s['excluded']=False;s['confirmed']=False;s.pop('reviewed_findings',None)
            if 'PRIVATE KEY-----'in value:s['kind']='private'
        else:error('privacy_invalid_parameter',400)
        s['revision']+=1;self.change(t);return self.public(t)

    async def build(self,task_id,owner,body):
        t=self.get(task_id,owner);self.expect(t,body.get('expected_task_revision'))
        snapshot=copy.deepcopy(t);snapshot.pop('manifest',None)
        account=await self.accounts.call('resolve',snapshot['destination'])
        account_policy=await self.repo.call('policy',snapshot['destination'])
        def analyze():
            mapping=dict(snapshot['aliases']);items=[];findings=[];parts=[]
            inputs=([dict(id='purpose',revision=snapshot['revision'],text=snapshot['purpose'],kind='text',excluded=False,confirmed=True)] if not snapshot.get('native_request')else [])+snapshot['sources']
            # Scan eligible source texts together before replacing, so a credential learned
            # from one file is removed from bare repetitions in another material.
            eligible=[];early_errors={}
            for i,source in enumerate(inputs):
                if source['excluded'] or source['kind'] in ('private','opaque'):continue
                try:sanitize(source['text'],mapping,(account['key'],));eligible.append((i,source['text']))
                except ServiceError as exc:early_errors[i]=exc
            shared={}
            if eligible:
                sanitized,all_findings,mapping=sanitize([value for _,value in eligible],mapping,(account['key'],))
                for position,(i,_) in enumerate(eligible):
                    shared[i]=(sanitized[position],[f for f in all_findings if f['path'].split('/')[1]==str(position)])
            for i,s in enumerate(inputs):
                row=dict(material_id=s['id'],material_revision=s['revision'],status='included',reason_code='checked',safe_preview=None,findings=[])
                if s['excluded'] or s['kind']=='private':
                    row.update(status='excluded',reason_code='user_excluded' if s['excluded']else 'credential_file')
                    if s['kind']=='private':
                        finding=dict(category='secret',action='exclude',material_index=i,rule_id='private_material')
                        row['findings']=[finding];findings.append(finding)
                elif s['kind']=='opaque':row.update(status='blocked',reason_code='uninspectable')
                else:
                    try:
                        if i in early_errors:raise early_errors[i]
                        safe,f=shared[i]
                        policy_reason=policy_action(f,account_policy)
                        f=[dict(x,material_index=i)for x in s.get('reviewed_findings',[])+f];row['findings']=f;findings.extend(f)
                        if policy_reason or (s['kind']in ('identity','unknown','code')and not s['confirmed']):
                            row.update(status='pending',reason_code=policy_reason or 'purpose_or_semantics',safe_preview=safe)
                        else:parts.append(safe if snapshot.get('native_request')else ('任务'if i==0 else '材料 '+str(i))+':\n'+safe)
                    except ServiceError as exc:row.update(status='blocked',reason_code=exc.code)
                items.append(row)
            return items,findings,parts,mapping
        items,findings,parts,mapping=await self.scan(analyze)
        self.get(task_id,owner);self.expect(t,snapshot['revision'])
        joined='\n\n'.join(parts)
        protocol=t['protocol'];model=t['model']
        if protocol=='responses':doc={'model':model,'input':joined,'stream':True};path='/responses'
        else:
            doc={'model':model,'messages':[{'role':'user','content':joined}],'stream':True}
            path='/messages'if protocol=='messages'else '/chat/completions'
            if protocol=='messages':doc['max_tokens']=2048
        blocked=any(i['status']=='blocked'for i in items);pending=any(i['status']=='pending'for i in items)
        state='blocked'if blocked else 'needs_review'if pending else 'ready'
        raw=json.dumps(doc,ensure_ascii=False).encode()
        # Final structural/model validation; model names are arbitrary but cannot carry secrets.
        if state=='ready':
            try:
                headers={'Content-Type':'application/json','Anthropic-Version':'2023-06-01'}if protocol=='messages'else {'Content-Type':'application/json'}
                if t.get('native_request'):
                    if len(parts)!=1:error('privacy_invalid_request',422)
                    raw=parts[0].encode();path=t['native_path'];headers=t['native_headers']
                    native=strict_json(raw)
                    if not isinstance(native,dict) or native.get('model')!=t['model']:error('privacy_changed')
                clean,final_findings,safe_headers=await self.scan(inspect_request,raw,path,'POST',headers,(account['key'],))
                if policy_action(final_findings,account_policy):fail(policy_action(final_findings,account_policy),409)
            except ServiceError as exc:state='blocked';items.append(dict(material_id='envelope',material_revision=1,status='blocked',reason_code=exc.code,safe_preview=None,findings=[]));clean=b'';safe_headers={}
        else:clean=b'';safe_headers={}
        self.get(task_id,owner);self.expect(t,snapshot['revision'])
        m=dict(id=ident(),task_id=t['id'],task_revision=t['revision'],round=t['round'],destination_id=t['destination'],
               policy_revision=account_policy['revision'],ruleset_version=RULESET,state=state,items=items,sanitized_preview=joined,
               release_token=secrets.token_urlsafe(32)if state=='ready'else None,expires_at=time.time()+120)
        if (await self.repo.call('policy',t['destination']))['revision']!=account_policy['revision']:error('privacy_changed')
        audit_reason='manual_review' if state=='needs_review'else next((i['reason_code'] for i in items if i['status']=='blocked'),'redacted'if findings else 'checked')
        audit=await self.repo.call('create',t['destination'],'blocked' if state!='ready'else 'redacted' if findings else 'release',findings,'workbench',t['round'],sum(i['status']=='included' and i['material_id']!='purpose'for i in items),sum(i['status']=='excluded'for i in items),
            {'reason_code':audit_reason,'event_kind':'inspection','policy_revision':account_policy['revision'],'parent_id':t.get('origin_record_id')})
        self.get(task_id,owner);self.expect(t,snapshot['revision'])
        m['record_id']=audit
        t['manifest']=dict(public=m,**{'state':state,'deadline':time.monotonic()+120,'body':clean,'headers':safe_headers,'path':path,
                 'account_revision':account['config_revision'],'aliases':mapping,'findings':findings,'used':False})
        return m

    async def review(self,task_id,owner,body):
        t=self.get(task_id,owner);self.expect(t,body.get('expected_task_revision'))
        m=self._manifest(t,body.get('manifest_id'))
        s=next((s for s in t['sources']if s['id']==body.get('material_id')),None)
        row=next((i for i in m['public']['items']if i['material_id']==body.get('material_id')),None)
        if not s or not row or body.get('material_revision')!=s['revision']:error('privacy_changed')
        if body.get('action')=='exclude':s['excluded']=True
        elif body.get('action')=='approve_sanitized' and row['status']=='pending':
            candidate=text(body.get('sanitized_text',row['safe_preview']),MAX_BYTES,True)
            revision=t['revision'];account=await self.accounts.call('resolve',t['destination'])
            safe,review_findings,_=await self.scan(sanitize,candidate,{},(account['key'],))
            self.get(task_id,owner);self.expect(t,revision);self._manifest(t,body.get('manifest_id'))
            s['text']=safe;s['confirmed']=True;t['aliases']=dict(m['aliases'])
            s['reviewed_findings']=row['findings']+review_findings
        else:error('privacy_original_not_approvable',422)
        s['revision']+=1;self.change(t)
        return dict(task_revision=t['revision'],manifest_invalidated=True,needs_rebuild=True)

    def _manifest(self,t,mid):
        m=t.get('manifest')
        if not m or m['public']['id']!=mid or m['public']['task_revision']!=t['revision']:error('privacy_changed')
        if time.monotonic()>m['deadline']:error('privacy_expired',410)
        return m

    async def release(self,task_id,owner,body):
        t=self.get(task_id,owner);key=text(body.get('idempotency_key'),200)
        for r in self.releases.values():
            if r['owner']==owner and r['key']==key:
                if r['task_id']!=task_id or r['manifest_id']!=body.get('manifest_id')or r['destination']!=body.get('destination_id'):error('privacy_changed')
                return r['public']
        self.expect(t,body.get('expected_task_revision'));m=self._manifest(t,body.get('manifest_id'))
        if m['used']or m['state']!='ready':error('privacy_review_required')
        if not isinstance(body.get('release_token'),str)or not secrets.compare_digest(m['public']['release_token'],body['release_token']):error('privacy_forbidden',403)
        if t['destination']!=body.get('destination_id'):error('privacy_changed')
        if len(self.releases)>=64:error('privacy_capacity',503)
        # Reserve before any await: concurrent release cannot send twice, including different keys.
        m['used']=True
        account=await self.accounts.call('resolve',t['destination'])
        self.get(task_id,owner);self.expect(t,m['public']['task_revision'])
        if account['config_revision']!=m['account_revision']:error('privacy_changed')
        if (await self.repo.call('policy',t['destination']))['revision']!=m['public']['policy_revision']:error('privacy_changed')
        rid=ident();r=dict(id=rid,owner=owner,key=key,task_id=task_id,manifest_id=m['public']['id'],destination=t['destination'],
              created=time.monotonic(),started=asyncio.Event(),subscriber=asyncio.Event(),queue=asyncio.Queue(8),claimed=False,
              status=None,headers={},job=None,done=False)
        record=await self.repo.call('create',t['destination'],'redacted' if m['findings'] else 'release',m['findings'],'workbench',t['round'],
                   sum(i['status']=='included' and i['material_id']!='purpose' for i in m['public']['items']),sum(i['status']=='excluded'for i in m['public']['items']),{'policy_revision':m['public']['policy_revision'],'parent_id':m['public']['record_id']})
        try:
            self.get(task_id,owner);self.expect(t,m['public']['task_revision'])
        except ServiceError:
            await self.state(record,'cancelled');raise
        approved=Approved(m['body'],m['headers'],record,m['path'],account['id'],account['config_revision'],self.seal,m['public']['policy_revision'])
        r['public']=dict(release_id=rid,record_id=record,forward_state='authorized',response_route='/api/privacy/releases/'+rid+'/response')
        t['aliases']=m['aliases'];self.releases[rid]=r
        r['job']=asyncio.create_task(self._produce(r,approved,account))
        return r['public']

    async def _produce(self,r,approved,account):
        try:
            async with self.transport.approved_request(account,'POST',approved) as response:
                r['public']['forward_state']='forwarding';r['status']=response.status
                from provider.auth import clean_headers
                r['headers']=clean_headers(response.headers);r['started'].set()
                await asyncio.wait_for(r['subscriber'].wait(),15)
                async for chunk in response.content.iter_chunked(65536):
                    await asyncio.wait_for(r['queue'].put(chunk),15)
                r['public']['forward_state']='completed'if 200<=response.status<300 else 'failed'
        except asyncio.CancelledError:
            r['public']['forward_state']='cancelled';await self.state(approved.record_id,'cancelled')
        except Exception:
            r['public']['forward_state']='failed';await self.state(approved.record_id,'failed')
        finally:
            r['done']=True;r['started'].set()
            # Consumer polls done when queue empty; no unbounded sentinel wait.

    def release_info(self,rid,owner):
        r=self.releases.get(rid)
        if not r:error('privacy_release_unavailable',410)
        if r['owner']!=owner:error('privacy_forbidden',403)
        return r

    def _end(self,t):
        for r in self.releases.values():
            if r['task_id']==t['id']:
                if r.get('job')and not r['job'].done():r['job'].cancel()
                while not r['queue'].empty():r['queue'].get_nowait()
                r['headers']={}
        t['sources'].clear();t['aliases'].clear();t.pop('manifest',None);t['purpose']=''

    def end(self,tid,owner):
        t=self.get(tid,owner);self._end(t);self.tasks.pop(tid,None);return {'task_id':tid,'state':'ended'}

    async def close(self):
        if self.maintenance:self.maintenance.cancel();await asyncio.gather(self.maintenance,return_exceptions=True)
        for t in self.tasks.values():self._end(t)
        await asyncio.gather(*(r['job']for r in self.releases.values()if r.get('job')),return_exceptions=True)
        self.tasks.clear();self.releases.clear();self.cases.clear()
        self.pool.shutdown(wait=True)
        await self.repo.close()


def re_binary(content):
    return sum(ord(c)<32 and c not in '\n\r\t'for c in content)>0
