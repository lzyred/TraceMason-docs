"""Bounded local recognizers; explicitly not a general-purpose NER model.

Recognition returns spans, not authority. Content requiring unsupported extraction
is refused. Only matched spans/known values are transformed, preserving JSON types.
"""
import copy
import json
import math
import base64
from urllib.parse import unquote
from privacy.standards import RULESET
import re
import time
import unicodedata
from errors import ServiceError

MAX_BYTES = 65536
MAX_DEPTH = 32
MAX_LEAVES = 4096


def fail(code, status=422):
    raise ServiceError(status, code, {
        'privacy_review_required': '内容无法完整检查或需要人工整理，请在防护工作台处理。',
        'privacy_timeout': '本机检查超时，原文未外发。',
        'privacy_too_large': '请求超过检查容量，原文未外发。',
        'privacy_invalid_json': '请求 JSON 无效或含重复字段，原文未外发。',
    }.get(code, '无法安全检查该请求，原文未外发。'))


def strict_json(raw):
    def pairs(items):
        out = {}
        for k, v in items:
            if k in out:
                fail('privacy_invalid_json', 400)
            out[k] = v
        return out
    def constant(_):
        fail('privacy_invalid_json', 400)
    try:
        if isinstance(raw, bytes):raw=raw.decode('utf-8',errors='strict')
        result=json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
        json.dumps(result,ensure_ascii=False,allow_nan=False).encode('utf-8',errors='strict')
        return result
    except (ValueError, UnicodeError, RecursionError, OverflowError):
        fail('privacy_invalid_json', 400)


# A rule is (category, label, regex, sensitive capture group).
RULES = [
    ('secret', '认证秘密', r'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----', 0),
    ('secret', '认证秘密', r'\b(?:sk-(?:proj-|ant-)?|rk-|ghp_|github_pat_|AKIA)[A-Za-z0-9_-]{12,}', 0),
    ('secret', '认证秘密', r'\bBearer\s+([A-Za-z0-9._~+/=-]{8,})', 1),
    ('secret', '认证秘密', r'(?:密码|口令|验证码|校验码|password|passwd|pwd|secret|api[_ -]?key|access[_ -]?token|token|otp|verification_code)["\']?\s*(?:为|是|[:=：])\s*(["\'])([^\r\n]*?)\1', 2),
    ('secret', '认证秘密', r'(?:密码|口令|验证码|校验码|password|passwd|pwd|secret|api[_ -]?key|access[_ -]?token|token|otp|verification_code)["\']?\s*(?:为|是|[:=：])\s*([^\s"\'，,;；。}\]]+)', 1),
    ('secret', '连接凭据', r'\b(?:postgres(?:ql)?|mysql|redis|mongodb(?:\+srv)?|ssh)://[^\s"\'<>]+', 0),
    ('identity', '邮箱', r'[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}', 0),
    ('identity', '手机号', r'(?<!\d)(?:\+86[- ]?)?1[3-9]\d{9}(?!\d)', 0),
    ('identity', '身份证', r'(?<!\w)[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx](?!\w)', 0),
    ('identity', '姓名', r'(?:姓名|联系人|full_name)["\']?\s*(?:为|是|[:=：])\s*([^\s"\'，,;；。}\]]+)', 1),
    ('identity', '地址', r'(?:家庭住址|家庭地址|收货地址)["\']?\s*(?:为|是|[:=：])\s*([^\n"\'，,;；。}\]]+)', 1),
    ('identity', '本机用户', r'(?:/Users/|/home/)([^/\s"\']+)', 1),
    ('identity', '本机用户', r'[A-Za-z]:\\Users\\([^\\\s"\']+)', 1),
    ('identity', '账号', r'(?:账号|帐号|用户名|username|user_name|login_user|DB_USER|SSH_USER)["\']?\s*(?:为|是|[:=：])\s*([^\s"\'，,;；。}\]]+)', 1),
    ('environment', '服务器', r'(?:服务器(?:地址|IP)?|主机(?:地址)?|server[_ -]?(?:host|ip)|hostname|host)["\']?\s*(?:为|是|[:=：])\s*([^\s"\'，,;；。}\]]+)', 1),
    ('environment', 'SSH登录', r'\b(?:ssh|scp)\s+(?:-p\s+\d+\s+)?([^\s;，。]+@[^\s;，。]+)', 1),
]
RULES += [
    ('secret','认证秘密',r'(?:refresh[_ -]?token|session[_ -]?token|client[_ -]?secret|secret[_ -]?access[_ -]?key|access[_ -]?key)["\']?\s*[:=：]\s*["\']?([^\s"\'，,;；。}\]]+)',1),
    ('secret','会话凭据',r'(?:authorization|cookie|set-cookie)\s*:\s*([^\r\n]+)',1),
    ('secret','认证秘密',r'\bBasic\s+([A-Za-z0-9+/]{8,}={0,2})',1),
    ('secret','JWT',r'\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}',0),
    ('secret','连接凭据',r'https?://[^\s/@:]+:[^\s/@]+@[^\s"<>]+',0),
    ('secret','认证秘密',r'sshpass\s+-p\s+["\']?([^\s"\']+)',1),
    ('identity','姓名',r'(?:我叫|我的姓名是|我的名字是)\s*([^\s，。；！!、\[\]]{2,8})',1),
    ('identity','姓名',r'(?:姓名|联系人|full_name)["\']?\s*[:=：]\s*["\']([^"\'\n]+)["\']',1),
]
RULES = [(a, b, re.compile(c, re.I), d) for a, b, c, d in RULES]
PLACEHOLDER = re.compile(r'\[(?:(?:邮箱|手机号|身份证|姓名|地址|本机用户|账号|服务器|SSH登录)_\d+|认证秘密已移除)\]')
SECRET_FIELDS = {'password', 'passwd', 'pwd', 'secret', 'api_key', 'apikey', 'access_token', 'token', 'secret_access_key', 'access_key', 'authorization', 'cookie', 'set_cookie', 'refresh_token', 'session_token', 'private_key', 'otp', 'verification_code', 'client_secret'}
IDENTITY_FIELDS = {'username': '账号', 'user_name': '账号', 'login_user': '账号', 'name': '姓名', 'full_name': '姓名', 'address': '地址', 'email': '邮箱', 'phone': '手机号'}
ENV_FIELDS = {'host', 'hostname', 'server_ip', 'db_host', 'ssh_host'}
STRUCTURAL = {'model', 'role', 'type', 'id', 'call_id', 'tool_call_id'}
OPAQUE_FIELDS = {'container', 'conversation', 'image_url', 'file_id', 'file_data', 'input_audio', 'audio', 'attachments', 'file_url', 'document_url'}
OPAQUE_TYPES = {'image', 'image_url', 'input_image', 'audio', 'input_audio', 'document', 'file', 'input_file'}


def canonical_field(value):
    value=normalize(value)[0]
    value=re.sub(r'([a-z])([A-Z])',r'\1_\2',value)
    return re.sub(r'[\s-]+','_',value).lower()


def field_category(field):
    if field in SECRET_FIELDS or any(field.endswith('_'+name)for name in SECRET_FIELDS if name not in ('cookie','authorization')):return 'secret'
    if field in IDENTITY_FIELDS:return 'identity'
    if field in ENV_FIELDS:return 'environment'
    return None


def encoded_evidence(value):
    # Detect known sensitive evidence inside bounded encodings; never silently forward or decode for execution.
    candidates=[]
    if re.search(r'\\u[0-9a-fA-F]{4}|%[0-9a-fA-F]{2}',value):
        decoded=value
        for _ in range(2):
            decoded=unquote(decoded)
            decoded=re.sub(r'\\u([0-9a-fA-F]{4})',lambda m:chr(int(m[1],16)),decoded)
        if decoded!=value:candidates.append(decoded)
    encoded=list(re.finditer(r'(?<![A-Za-z0-9+/_-])[A-Za-z0-9+/_-]{16,}={0,2}(?![A-Za-z0-9+/_-])',value))
    if len(encoded)>32:fail('privacy_complexity_limit')
    for m in encoded:
        if len(m[0])>8192:continue
        try:
            decoded=base64.b64decode(m[0]+'='*((-len(m[0]))%4),altchars=b'-_',validate=True).decode('utf-8')
            candidates.append(decoded)
        except (ValueError,UnicodeError):pass
    for decoded in candidates:
        if any(pattern.search(decoded)for _,_,pattern,_ in RULES):return True
    return False


def normalize(text):
    # Normalize for recognition only. Original offsets and untouched bytes remain intact.
    out, positions = [], []
    for i, char in enumerate(text):
        if char in '\u200b\u200c\u200d\ufeff':
            continue
        for c in unicodedata.normalize('NFKC', char):
            out.append(c)
            positions.append(i)
    return ''.join(out), positions


def sanitize(document, aliases=None, known_secrets=(), budget=1.0):
    began = time.monotonic()
    aliases = dict(aliases or {})
    try: document_size=len(json.dumps(document, ensure_ascii=False,allow_nan=False).encode())
    except (ValueError,UnicodeError,RecursionError):fail('privacy_invalid_json',400)
    if document_size > MAX_BYTES:
        fail('privacy_too_large', 413)
    leaves = []
    protected_paths = set()
    reserved = set()
    def tick():
        if time.monotonic() - began > budget:
            fail('privacy_timeout', 503)
    # Tool arguments and pasted JSON are strings on the wire, but contain typed
    # data. Inspect their parsed values, then restore the string envelope.
    embedded = {}; nodes = 0
    def expand(node, path=(), depth=0):
        nonlocal nodes
        tick();nodes+=1
        if depth>MAX_DEPTH or nodes>MAX_LEAVES:fail('privacy_complexity_limit')
        if isinstance(node,str) and node.lstrip().startswith(('{','[')):
            try:parsed=strict_json(node)
            except ServiceError:
                if (path and path[-1]=='arguments') or re.match(r'\s*(?:\{\s*"|\[\s*[{"])',node):fail('privacy_invalid_json',400)
                return node
            if isinstance(parsed,(dict,list)):
                embedded[path]=(node,parsed)
                return expand(parsed,path,depth+1)
        if isinstance(node,dict):return {k:expand(v,path+(k,),depth+1)for k,v in node.items()}
        if isinstance(node,list):return [expand(v,path+(i,),depth+1)for i,v in enumerate(node)]
        return node
    document=expand(document)
    def collect(node, path=(), depth=0, key=False):
        tick()
        if depth > MAX_DEPTH or len(leaves) > MAX_LEAVES:
            fail('privacy_complexity_limit')
        field = canonical_field(str(path[-1])) if path else ''
        # A JSON Schema describes fields; its property names are not user values.
        # Defaults/examples remain content and are still checked.
        schema = (('tools' in path and any(k in path for k in ('parameters','input_schema'))) or
                  ('schema' in path and ('response_format' in path or 'format' in path)))
        semantic_field = field
        if schema:
            semantic_field = ''
            if field in ('default','const','examples','enum') and 'properties' in path:
                at=max(i for i,k in enumerate(path) if k=='properties')
                if at+1<len(path):semantic_field=canonical_field(str(path[at+1]))
        if isinstance(node, str):
            if encoded_evidence(node):fail('privacy_encoded_content')
            if re.search(r'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----', node) and not re.search(r'-----END (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----', node):
                fail('privacy_review_required')
            if any('\u202a' <= c <= '\u202e' for c in node):
                fail('privacy_review_required')
            # Data URIs and long opaque encodings cannot be attested as inspected text.
            if re.search(r'data:[^\s,;]+[;,]|[A-Za-z0-9+/]{256,}={0,2}', node):
                fail('privacy_review_required')
            protected = key or path in protected_paths or field in STRUCTURAL or (field == 'name' and any(k in ('function', 'tools', 'tool_calls') for k in path))
            norm, offsets = normalize(node)
            leaves.append((path, node, semantic_field, protected, key, norm, offsets))
            reserved.update(re.findall(r'\[[^\]\n]+_\d+\]', node))
        elif isinstance(node, dict):
            if field_category(semantic_field):fail('privacy_typed_sensitive_field')
            if node.get('type') in ('tool_use','function_call','custom_tool_call'):
                protected_paths.add(path+('name',))
            if isinstance(node.get('type'),str) and (node['type']=='mcp' or node['type'].startswith('computer')) or node.get('server_url') or node.get('connector_id'):
                fail('privacy_remote_tool')
            if isinstance(node.get('type'), str) and node['type'] in OPAQUE_TYPES:
                fail('privacy_review_required')
            for k, v in node.items():
                if k in OPAQUE_FIELDS and v:
                    fail('privacy_review_required')
                collect(k, path + ('@key',), depth+1, True)
                collect(v, path + (k,), depth+1)
        elif isinstance(node, list):
            if field_category(semantic_field):fail('privacy_typed_sensitive_field')
            if node and all(isinstance(v,dict) and isinstance(v.get('text'),str) for v in node):
                texts=[normalize(v['text'])[0] for v in node]
                joined=''.join(texts);boundaries=[];offset=0
                for value in texts[:-1]:offset+=len(value);boundaries.append(offset)
                for _,_,pattern,group in RULES:
                    for m in pattern.finditer(joined):
                        if any(m.start()<b<m.end() for b in boundaries):fail('privacy_cross_block')
            for i, v in enumerate(node): collect(v, path + (i,), depth+1)
        elif isinstance(node, float) and not math.isfinite(node):
            fail('privacy_invalid_json',400)
        elif (isinstance(node, (int, float, bool)) and
              field_category(semantic_field)):
            fail('privacy_typed_sensitive_field')
        elif node is not None and not isinstance(node, (int, float, bool)):
            fail('privacy_review_required')
    collect(document)
    candidates = {}
    def remember(value, category, label, rule):
        if value and not (value=='[认证秘密已移除]' if category=='secret' else PLACEHOLDER.fullmatch(value)):
            # Secrets take priority; never retain them in the cross-round alias map.
            if value not in candidates or category == 'secret':
                candidates[value] = (category, label, rule)
    for value, alias in aliases.items():
        remember(value, 'identity', alias.strip('[]').rsplit('_',1)[0], 'task_alias')
    for path, original, field, protected, key, norm, offsets in leaves:
        tick()
        if not protected:
            if field_category(field)=='secret': remember(original, 'secret', '认证秘密', 'sensitive_field')
            elif field in IDENTITY_FIELDS: remember(original, 'identity', IDENTITY_FIELDS[field], 'identity_field')
            elif field in ENV_FIELDS: remember(original, 'environment', '服务器', 'environment_field')
        for category, label, pattern, group in RULES:
            placeholders = [m.span() for m in PLACEHOLDER.finditer(norm)]
            for match in pattern.finditer(norm):
                a, b = match.span(group)
                if any(x <= a and b <= y for x,y in placeholders):continue
                if a < b:
                    remember(original[offsets[a]:offsets[b-1]+1], category, label, 'local_'+label)
        for value in known_secrets:
            if value and value in original: remember(value, 'secret', '认证秘密', 'provider_secret_in_body')
    if len(candidates) > 256:
        fail('privacy_complexity_limit')
    replacements = {}
    for value, (category, label, rule) in sorted(candidates.items(), key=lambda v: -len(v[0])):
        if category == 'secret':
            replacement = '[认证秘密已移除]'
            # A value previously used as an identity may later be identified as
            # a credential. Do not keep that credential in the task alias map.
            aliases.pop(value,None)
        else:
            replacement = aliases.get(value)
            if not replacement:
                index = 1
                while '[%s_%s]' % (label, index) in reserved or '[%s_%s]' % (label, index) in aliases.values(): index += 1
                replacement = '[%s_%s]' % (label, index)
                aliases[value] = replacement
                reserved.add(replacement)
        replacements[value] = replacement
    result, findings = copy.deepcopy(document), []
    def locate(text, value):
        start = 0
        while True:
            index = text.find(value, start)
            if index < 0: return
            end = index+len(value); start = end
            if re.fullmatch(r'[A-Za-z0-9_]{1,12}', value):
                if (index and re.match(r'[A-Za-z0-9_]', text[index-1])) or (end < len(text) and re.match(r'[A-Za-z0-9_]', text[end])): continue
            yield index, end
    for path, text, field, protected, key, _, _ in leaves:
        tick()
        spans = []
        for value, replacement in replacements.items():
            for a, b in locate(text, value):
                if any(a < y and b > x for x, y, _, _ in spans): continue
                spans.append((a, b, value, replacement))
        if not spans: continue
        if protected:
            fail('privacy_sensitive_structure')
        spans.sort()
        parts, previous = [], 0
        for a, b, value, replacement in spans:
            category, _, rule = candidates[value]
            parts.extend((text[previous:a], replacement)); previous = b
            findings.append({'category': category, 'action': 'remove' if category == 'secret' else 'alias',
                             'placeholder': replacement, 'rule_id': rule,
                             'path': '/'+'/'.join(str(k) if isinstance(k, int) or k in ('messages', 'content', 'input', 'text', 'system', 'instructions', 'metadata') else '[field]' for k in path)})
        parts.append(text[previous:]); transformed = ''.join(parts)
        # Never use replacements as new matching inputs.
        remainder = PLACEHOLDER.sub('', transformed)
        if any(list(locate(remainder, value)) for value in replacements): fail('privacy_residual_secret')
        if not path: result = transformed
        else:
            parent = result
            for k in path[:-1]: parent = parent[k]
            parent[path[-1]] = transformed
    tick()
    if len(aliases) > 512: fail('privacy_alias_capacity', 503)
    for path,(original,parsed) in sorted(embedded.items(),key=lambda item:len(item[0]),reverse=True):
        if path:
            parent=result
            for k in path[:-1]:parent=parent[k]
            value=parent[path[-1]]
            parent[path[-1]]=original if value==parsed else json.dumps(value,ensure_ascii=False,separators=(',',':'))
        else:result=original if result==parsed else json.dumps(result,ensure_ascii=False,separators=(',',':'))
    return result, findings, aliases


def inspect_request(raw, path, method, headers, known_secrets=()):
    if len(raw) > MAX_BYTES: fail('privacy_too_large', 413)
    if '?' in path or '%' in path or '\\' in path: fail('privacy_uninspectable_route')
    if headers.get('Upgrade', '').lower() == 'websocket': fail('privacy_unsupported_protocol')
    if headers.get('Content-Encoding'): fail('privacy_unsupported_encoding')
    if method == 'GET' and path in ('/models', '/v1/models') and not raw:
        return b'', [], {'Accept': 'application/json'}
    if method != 'POST' or path not in ('/responses', '/v1/responses', '/chat/completions', '/v1/chat/completions', '/messages', '/v1/messages'):
        fail('privacy_unsupported_protocol')
    if headers.get('Content-Type', '').split(';')[0].strip().lower() != 'application/json':
        fail('privacy_unsupported_content_type')
    doc = strict_json(raw)
    if not isinstance(doc, dict): fail('privacy_invalid_json', 400)
    if path.endswith('/responses'):
        if not isinstance(doc.get('input'), (str, list)): fail('privacy_invalid_request', 400)
        if doc.get('previous_response_id'): fail('privacy_remote_history_unavailable')
    elif not isinstance(doc.get('messages'), list): fail('privacy_invalid_request', 400)
    clean, findings, _ = sanitize(doc, known_secrets=known_secrets)
    safe_headers = {'Content-Type': 'application/json'}
    for key in ('Anthropic-Version', 'Anthropic-Beta', 'OpenAI-Beta'):
        value = headers.get(key)
        if value:
            if not re.fullmatch(r'[A-Za-z0-9,._ -]{1,256}', value): fail('privacy_unsafe_header')
            _, found, _ = sanitize(value, known_secrets=known_secrets)
            if found: fail('privacy_unsafe_header')
            safe_headers[key] = value
    return json.dumps(clean, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode(), findings, safe_headers
