"""Persist only enumerated decision metadata. No originals, filenames or mappings."""
import asyncio
import json
import os
import sqlite3
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from errors import ServiceError
from privacy.standards import RULESET, POLICY_VERSION, REASONS, RULE_NAMES, policy_defaults


class PrivacyRepository:
    def __init__(self, path):
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix='privacy-db')
        self.pool.submit(self._open, path).result()

    def _open(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(path), timeout=1)
        os.chmod(path, 0o600)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
              decision TEXT NOT NULL, state TEXT NOT NULL, source TEXT NOT NULL, round INTEGER NOT NULL,
              included INTEGER NOT NULL, excluded INTEGER NOT NULL, findings TEXT NOT NULL,
              created REAL NOT NULL, expires REAL NOT NULL);
            CREATE INDEX IF NOT EXISTS record_created ON records(created DESC);
            CREATE INDEX IF NOT EXISTS record_account ON records(account_id,created DESC);
        ''')
        columns={row[1] for row in self.db.execute('PRAGMA table_info(records)')}
        for name,definition in [('reason_code',"TEXT NOT NULL DEFAULT 'legacy'"),('policy_revision','INTEGER NOT NULL DEFAULT 1'),('ruleset',"TEXT NOT NULL DEFAULT 'local-context-1'"),('parent_id','TEXT'),('event_kind',"TEXT NOT NULL DEFAULT 'forward'")]:
            if name not in columns:self.db.execute('ALTER TABLE records ADD COLUMN '+name+' '+definition)
        self.db.execute('CREATE TABLE IF NOT EXISTS policies(account_id TEXT PRIMARY KEY, revision INTEGER NOT NULL, secrets_action TEXT NOT NULL, identity_action TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS policy_changes(id TEXT PRIMARY KEY, account_id TEXT NOT NULL, revision INTEGER NOT NULL, secrets_action TEXT NOT NULL, identity_action TEXT NOT NULL, created REAL NOT NULL)')
        self.db.commit()
        with self.db:
            self.db.execute("UPDATE records SET state='interrupted' WHERE state IN ('authorized','forwarding')")
            self.db.execute('DELETE FROM records WHERE expires<=?', (time.time(),))

    async def call(self, method, *args):
        try:
            return await asyncio.get_running_loop().run_in_executor(self.pool, lambda: getattr(self, '_'+method)(*args))
        except sqlite3.Error:
            raise ServiceError(503, 'privacy_store_unavailable', '风险记录不可写，未允许新的风险请求外发。') from None

    def _create(self, account, decision, findings, source, round_number=1, included=0, excluded=0, metadata=None):
        # Findings are rebuilt from a closed set, never serialize arbitrary scanner objects.
        metadata=metadata or {}
        safe = []
        for f in findings[:512]:
            if f.get('category') not in ('secret', 'identity', 'environment'): continue
            if f.get('action') not in ('remove','alias','exclude'):continue
            safe.append({'category': f['category'], 'action': f['action'],
                         'material_index': int(f.get('material_index', 0)), 'ruleset': RULESET,
                         'rule_id': f.get('rule_id') if f.get('rule_id') in RULE_NAMES else 'sensitive_field'})
        ident, now = metadata.get('id') or uuid.uuid4().hex, time.time()
        reason=metadata.get('reason_code','redacted' if findings else 'checked')
        if reason not in REASONS:reason='privacy_internal_error'
        event=metadata.get('event_kind','forward')
        if event not in ('forward','inspection'):event='forward'
        with self.db:
            self.db.execute('INSERT INTO records(id,account_id,decision,state,source,round,included,excluded,findings,created,expires,reason_code,policy_revision,ruleset,parent_id,event_kind) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                (ident, account, decision, 'not_sent' if decision == 'blocked' or event=='inspection' else 'authorized', source,
                 round_number, included, excluded, json.dumps(safe), now, now+30*86400,reason,int(metadata.get('policy_revision',1)),RULESET,metadata.get('parent_id'),event))
        return ident

    def _state(self, ident, state):
        if ident:
            with self.db: self.db.execute('UPDATE records SET state=? WHERE id=?', (state, ident))

    def _list(self, filters, page=1, size=20):
        where, args = self._where(filters)
        total = self.db.execute('SELECT count(*) FROM records WHERE '+where, args).fetchone()[0]
        rows = self.db.execute('SELECT * FROM records WHERE '+where+' ORDER BY created DESC,id DESC LIMIT ? OFFSET ?', (*args,size,(page-1)*size)).fetchall()
        return {'items': [self._public(row) for row in rows], 'total': total, 'page': page, 'page_size': size}

    def _where(self, filters):
        clauses, args = ['expires>?'], [time.time()]
        for key, col in [('destination_id','account_id'),('decision','decision')]:
            if filters.get(key): clauses.append(col+'=?');args.append(filters[key])
        for key, op in [('since','>='),('until','<')]:
            if filters.get(key) is not None: clauses.append('created'+op+'?');args.append(filters[key])
        return ' AND '.join(clauses), args

    def _public(self, row):
        findings=json.loads(row['findings'])
        risk='high' if any(f['category']=='secret' for f in findings) else 'medium' if findings else 'unknown' if row['decision']=='blocked' else 'none'
        return dict(risk_level=risk,request_id=row['id'],reason_code=row['reason_code'],reason=REASONS.get(row['reason_code'],REASONS['legacy']),ruleset_version=row['ruleset'],parent_record_id=row['parent_id'],event_kind=row['event_kind'],id=row['id'], destination_id=row['account_id'], decision=row['decision'],
                    forward_state=row['state'], source=row['source'], round=row['round'],
                    included_count=row['included'], excluded_count=row['excluded'],
                    findings=findings, policy_revision=row['policy_revision'],
                    created_at=row['created'], expires_at=row['expires'])

    def _detail(self, ident):
        row=self.db.execute('SELECT * FROM records WHERE id=? AND expires>?',(ident,time.time())).fetchone()
        if row is None:raise ServiceError(404,'privacy_record_not_found','记录不存在或已到期。')
        return self._public(row)

    def _policy(self, account):
        row=self.db.execute('SELECT revision,secrets_action,identity_action FROM policies WHERE account_id=?',(account,)).fetchone()
        return dict(row) if row else policy_defaults()

    def _save_policy(self,account,body):
        current=self._policy(account)
        if type(body.get('expected_revision')) is not int or body['expected_revision']!=current['revision']:
            raise ServiceError(409,'privacy_changed','策略已变化，请刷新后重试。')
        if body.get('secrets_action') not in ('redact','block') or body.get('identity_action') not in ('alias','block'):
            raise ServiceError(400,'privacy_invalid_parameter','只能在脱敏与拦截之间选择，不能关闭检查或放行原始秘密。')
        updated=dict(revision=current['revision']+1,secrets_action=body['secrets_action'],identity_action=body['identity_action'])
        with self.db:
            self.db.execute('INSERT INTO policies VALUES(?,?,?,?) ON CONFLICT(account_id) DO UPDATE SET revision=excluded.revision,secrets_action=excluded.secrets_action,identity_action=excluded.identity_action',(account,updated['revision'],updated['secrets_action'],updated['identity_action']))
            self.db.execute('INSERT INTO policy_changes VALUES(?,?,?,?,?,?)',(uuid.uuid4().hex,account,updated['revision'],updated['secrets_action'],updated['identity_action'],time.time()))
        return updated

    def _policy_history(self,account):
        return [dict(row)for row in self.db.execute('SELECT revision,secrets_action,identity_action,created FROM policy_changes WHERE account_id=? ORDER BY revision DESC LIMIT 20',(account,))]

    def _preview(self, filters):
        where, args = self._where(filters)
        rows = self.db.execute("SELECT id FROM records WHERE "+where+" AND state NOT IN ('authorized','forwarding') LIMIT 10001",args).fetchall()
        if len(rows)>10000: raise ServiceError(413,'privacy_export_limit','请缩小记录筛选范围。')
        return [r[0] for r in rows]

    def _delete(self, ids):
        with self.db:
            count=0
            for ident in ids:
                count += self.db.execute("DELETE FROM records WHERE id=? AND state NOT IN ('authorized','forwarding')",(ident,)).rowcount
        return count

    def _purge(self):
        with self.db:
            self.db.execute('DELETE FROM records WHERE expires<=?',(time.time(),))
            self.db.execute('DELETE FROM policy_changes WHERE created<=?',(time.time()-30*86400,))

    async def close(self):
        await asyncio.get_running_loop().run_in_executor(self.pool,self.db.close)
        self.pool.shutdown(wait=True)
