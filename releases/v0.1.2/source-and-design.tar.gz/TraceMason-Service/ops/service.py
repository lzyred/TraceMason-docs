import asyncio
import re
import time
import aiohttp
from accounts.repository import now
from errors import ServiceError


class OpsService:
    def __init__(self, repository, transport, timeout=60):
        self.repository, self.transport, self.timeout = repository, transport, timeout

    async def check(self, command, etag):
        account = await self.repository.call('checked_account', command.get('id'), etag)
        spec = command.get('request')
        if not isinstance(spec, dict):
            raise ServiceError(400, 'invalid_request', '需要提供检查请求。')
        method, path, headers, body = (spec.get('method'), spec.get('path'), spec.get('headers', {}), spec.get('body', ''))
        if (not isinstance(method, str) or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", method)
                or not isinstance(path, str) or not isinstance(body, str) or not isinstance(headers, dict)
                or any(not isinstance(k, str) or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", k)
                       or not isinstance(v, str) or '\r' in v or '\n' in v for k, v in headers.items())):
            raise ServiceError(400, 'invalid_request', '检查请求格式无效。')
        started = time.monotonic()
        result = {'method':method, 'path': path if path in ('/models','/v1/models','/responses','/v1/responses','/chat/completions','/v1/chat/completions','/messages','/v1/messages') else '[unsupported]' , 'request_id':None, 'ok': False, 'scope': 'custom_request_only', 'http_status': None, 'error_code': None}
        async def consume():
            async with self.transport.request(account, method, path, headers, body.encode(), source='ops') as response:
                result['http_status'] = response.status
                rid = getattr(response,'_privacy_record_id',None)
                if rid and re.fullmatch(r'[A-Za-z0-9_.:-]{1,128}',rid) and account['key'] not in rid:
                    result['request_id'] = rid
                # Drain incrementally: never store upstream content or credentials in Ops.
                async for _ in response.content.iter_chunked(65536):
                    pass
                result['ok'] = 200 <= response.status < 300
                if not result['ok']:
                    result['error_code'] = ('upstream_auth' if response.status in (401, 403) else
                                            'upstream_rate_limit' if response.status == 429 else 'upstream_failed')
        try:
            await asyncio.wait_for(consume(), timeout=self.timeout)
        except asyncio.TimeoutError:
            result['error_code'] = 'upstream_timeout'
        except aiohttp.ClientConnectorCertificateError:
            result['error_code'] = 'upstream_tls'
        except aiohttp.ClientConnectorError:
            result['error_code'] = 'upstream_unreachable'
        except aiohttp.ClientPayloadError:
            result['error_code'] = 'upstream_incomplete'
        except aiohttp.ClientError:
            result['error_code'] = 'upstream_failed'
        result.update(tested_at=now(), duration_ms=round((time.monotonic() - started) * 1000))
        await self.repository.call('record_check', account, result)
        return result
