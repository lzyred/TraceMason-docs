"""TraceMason v0.1.2 local API access service."""
import argparse
import asyncio
import ipaddress
import json
import logging
import secrets
import sqlite3
from pathlib import Path
from aiohttp import web
from cryptography.exceptions import InvalidTag
from accounts.credential_store import CredentialStore, load_master_key
from accounts.service import AccountService
from provider.profiles import PROFILES
from provider.events import TransferEvents
import time
import signal
from errors import ServiceError
from ops.service import OpsService
from provider.transport import Transport
from privacy.service import PrivacyService
from privacy.routes import install as install_privacy

ROOT = Path(__file__).resolve().parent
REPO = web.AppKey('accounts', AccountService)
GATEWAY = web.AppKey('gateway-app', web.Application)
GATEWAY_URL = web.AppKey('gateway-url', str)
EVENTS = web.AppKey('events', TransferEvents)
RELAY = web.AppKey('transport', Transport)
OPS = web.AppKey('ops', OpsService)
TOKEN = web.AppKey('admin-token', str)
WEB = {'index.html', 'app.css', 'app.js', 'contract.js', 'api-client.js', 'privacy.html', 'privacy.css', 'privacy.js'}


@web.middleware
async def boundary(request, handler):
    try:
        sock = request.transport.get_extra_info('sockname')
        port = sock[1]
        host = request.headers.get('Host', '')
        if host not in {f'127.0.0.1:{port}', f'localhost:{port}', f'[::1]:{port}'}:
            raise ServiceError(403, 'invalid_host', '仅接受本机服务地址。')
        origin = request.headers.get('Origin')
        if ((origin is not None and origin != 'http://' + host)
                or request.headers.get('Sec-Fetch-Site') == 'cross-site'):
            raise ServiceError(403, 'invalid_origin', '拒绝跨站请求。')
        if TOKEN in request.app and request.path.startswith('/api/') and (request.method not in ('GET', 'HEAD') or request.path.startswith('/api/privacy/')):
            if not secrets.compare_digest(request.headers.get('X-TraceMason-Token', ''), request.app[TOKEN]):
                raise ServiceError(403, 'admin_token_required', '管理会话无效，请刷新后重试。')
        response = await handler(request)
    except ServiceError as exc:
        response = web.json_response(exc.body(), status=exc.status)
        if getattr(exc,'request_id',None):response.headers['X-TraceMason-Request-ID']=exc.request_id
        response.headers['Cache-Control']='no-store'
    except web.HTTPException as exc:
        response = web.json_response({'error': {'code': 'http_error', 'message': exc.reason}}, status=exc.status)
    except (json.JSONDecodeError, UnicodeError):
        response = web.json_response({'error': {'code': 'invalid_json', 'message': 'JSON 请求无效。'}}, status=400)
    except (sqlite3.Error, InvalidTag):
        # Do not log submitted values, credential ciphertext or upstream exception strings.
        response = web.json_response({'error': {'code': 'config_write_failed', 'message': '配置存储不可用。'}}, status=500)
    except asyncio.CancelledError:
        raise
    except Exception:
        logging.error('Unhandled service error at route %s', request.match_info.route.name)
        response = web.json_response({'error': {'code': 'internal_error', 'message': '服务处理失败。'}}, status=500)
    if not response.prepared and not request.path.startswith('/proxy/'):
        response.headers.update({'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
            'Referrer-Policy': 'no-referrer', 'Content-Security-Policy':
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"})
    return response


async def command(request):
    if request.content_type != 'application/json':
        raise ServiceError(415, 'invalid_content_type', '请使用 application/json。')
    body = await request.json()
    if not isinstance(body, dict):
        raise ServiceError(400, 'invalid_request', 'JSON 请求必须为对象。')
    return body


def reply(request, result):
    body, etag = result
    return web.json_response(body, headers={'ETag': etag})


async def session(request):
    return web.json_response({'token': request.app[TOKEN]})


async def providers(request):
    repo = request.app[REPO]
    if request.method == 'GET':
        return reply(request, await repo.call('view'))
    return reply(request, await repo.call('save', await command(request), request.headers.get('If-Match')))


async def enabled(request):
    body = await command(request)
    return reply(request, await request.app[REPO].call('enable', body.get('id'), body.get('enabled'), request.headers.get('If-Match')))


async def delete(request):
    return reply(request, await request.app[REPO].call('delete', request.match_info['id'], request.headers.get('If-Match')))


async def check(request):
    result = await request.app[OPS].check(await command(request), request.headers.get('If-Match'))
    return reply(request, (result, (await request.app[REPO].call('view'))[1]))


async def relay(request):
    started = time.monotonic()
    status, outcome = None, 'complete'
    try:
        account = await request.app[REPO].call('resolve', request.match_info['id'])
        path = '/' + request.raw_path.split('/', 3)[3]
        response = await request.app[RELAY].relay(request, account, path)
        status = response.status
        outcome = request.get('transfer_outcome', 'complete')
        return response
    except asyncio.CancelledError:
        outcome = 'cancelled'
        raise
    except Exception as exc:
        status, outcome = getattr(exc, 'status', 502), 'failed'
        raise
    finally:
        request.app[EVENTS].publish({'account_id':request.match_info['id'], 'method':request.method,
            'status':status,'outcome':outcome,'duration_ms':round((time.monotonic()-started)*1000)})


async def catalog(request):
    return web.json_response({'profiles': PROFILES, 'gateway_url': request.app[GATEWAY_URL]})


async def frontend(request):
    filename = request.match_info.get('file') or 'index.html'
    if filename not in WEB:
        raise web.HTTPNotFound()
    return web.FileResponse(ROOT / 'web' / filename)


def create_app(db_path, master_key, connect_timeout=15, idle_timeout=120, check_timeout=60):
    repo = AccountService(db_path, master_key)
    transport = Transport(connect_timeout, idle_timeout)
    privacy = PrivacyService(repo, db_path)
    transport.privacy = privacy
    privacy.transport = transport
    app = web.Application(middlewares=[boundary], client_max_size=4 * 1024 * 1024,
                          handler_args={'auto_decompress': False})
    app[REPO], app[RELAY], app[TOKEN] = repo, transport, secrets.token_urlsafe(32)
    app[OPS] = OpsService(repo, transport, check_timeout)
    app[GATEWAY_URL] = 'http://127.0.0.1:8768'
    events = TransferEvents()
    gateway = web.Application(middlewares=[boundary], handler_args={'auto_decompress':False})
    gateway[REPO], gateway[RELAY], gateway[EVENTS] = repo, transport, events
    gateway.router.add_route('*', '/proxy/{id}/{tail:.*}', relay)
    app[GATEWAY] = gateway
    async def lifecycle(app):
        await transport.start()
        await privacy.start()
        events.start()
        try:
            yield
        finally:
            await privacy.close()
            await transport.close()
            await events.close()
            await repo.close()
    app.cleanup_ctx.append(lifecycle)
    app.router.add_get('/api/session', session)
    app.router.add_get('/api/providers', providers)
    app.router.add_post('/api/providers', providers)
    app.router.add_post('/api/providers/enabled', enabled)
    app.router.add_post('/api/providers/test', check)
    app.router.add_delete('/api/providers/{id}', delete)
    app.router.add_get('/api/provider-profiles', catalog)
    install_privacy(app, privacy)
    app.router.add_get('/', frontend)
    app.router.add_get('/{file}', frontend)
    return app


def main():
    parser = argparse.ArgumentParser(description='TraceMason API 接入 v0.1.2')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--container', action='store_true', help='容器内允许监听 0.0.0.0；宿主机端口必须仅发布到 loopback')
    parser.add_argument('--port', type=int, default=8766)
    parser.add_argument('--proxy-port', type=int, default=8768)
    parser.add_argument('--data-dir', type=Path, default=ROOT / '.data')
    parser.add_argument('--master-key-file', type=Path)
    parser.add_argument('--connect-timeout', type=float, default=15)
    parser.add_argument('--idle-timeout', type=float, default=120)
    parser.add_argument('--check-timeout', type=float, default=60)
    args = parser.parse_args()
    if not ipaddress.ip_address(args.host).is_loopback and not (args.container and args.host == '0.0.0.0'):
        parser.error('v0.1.2 仅监听 loopback 地址。')
    if min(args.connect_timeout, args.idle_timeout, args.check_timeout) <= 0:
        parser.error('超时必须大于零。')
    db = args.data_dir / 'accounts.sqlite3'
    key = load_master_key(args.master_key_file or args.data_dir / 'master.key', db.exists())
    app = create_app(db, key, args.connect_timeout, args.idle_timeout, args.check_timeout)
    if args.port == args.proxy_port:
        parser.error('管理端口和转发端口必须不同。')
    async def run():
        app[GATEWAY_URL] = f'http://127.0.0.1:{args.proxy_port}'
        runners = []
        try:
            for instance, port in ((app,args.port),(app[GATEWAY],args.proxy_port)):
                runner = web.AppRunner(instance, access_log=None, handler_cancellation=True)
                runners.append(runner)
                await runner.setup()
                await web.TCPSite(runner,args.host,port).start()
            print(f'管理控制台 http://127.0.0.1:{args.port} | 转发 http://127.0.0.1:{args.proxy_port}',flush=True)
            stopped = asyncio.Event()
            for sig in (signal.SIGINT,signal.SIGTERM):
                asyncio.get_running_loop().add_signal_handler(sig,stopped.set)
            await stopped.wait()
        finally:
            for runner in reversed(runners):
                await runner.cleanup()
    asyncio.run(run())


if __name__ == '__main__':
    main()
