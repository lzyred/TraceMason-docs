"""Single SQLite transaction owns configuration, ciphertext and generation CAS."""
import json
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from errors import ServiceError


def now():
    return datetime.now(timezone.utc).isoformat()


class AccountRepository:
    def __init__(self, path, credentials):
        self.credentials = credentials
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.db = sqlite3.connect(str(path))
        os.chmod(path, 0o600)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
          PRAGMA journal_mode=WAL;
          PRAGMA busy_timeout=5000;
          CREATE TABLE IF NOT EXISTS meta(id INTEGER PRIMARY KEY CHECK(id=1), generation INTEGER NOT NULL, sentinel BLOB NOT NULL);
          CREATE TABLE IF NOT EXISTS accounts(id TEXT PRIMARY KEY, config TEXT NOT NULL, enabled INTEGER NOT NULL,
            credential BLOB, credential_revision INTEGER NOT NULL, config_revision INTEGER NOT NULL, probe TEXT);
          CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, account_id TEXT, operation TEXT, at TEXT);
          CREATE TABLE IF NOT EXISTS checks(id INTEGER PRIMARY KEY, account_id TEXT, result TEXT NOT NULL);
        ''')
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO meta VALUES(1,0,?)', (credentials.encrypt('TraceMason', '__master__', 1),))
        sentinel = self.db.execute('SELECT sentinel FROM meta').fetchone()[0]
        try:
            if credentials.decrypt(sentinel, '__master__', 1) != 'TraceMason':
                raise RuntimeError('Invalid master key')
        except BaseException:
            self.db.close()
            raise

    @property
    def etag(self):
        return '"config-%s"' % self.db.execute('SELECT generation FROM meta').fetchone()[0]

    def expect(self, etag):
        if not etag:
            raise ServiceError(428, 'precondition_required', '缺少配置快照，请刷新。')
        if etag != self.etag:
            raise ServiceError(412, 'config_changed', '配置已变更，请刷新后重试。')

    def row(self, account_id):
        if not isinstance(account_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", account_id):
            raise ServiceError(400, "invalid_provider_id", "账号标识格式无效。")
        row = self.db.execute('SELECT * FROM accounts WHERE id=?', (account_id,)).fetchone()
        if row is None:
            raise ServiceError(404, 'provider_not_found', '账号不存在。')
        return row

    def mutate(self, etag, operation, account_id, action):
        try:
            self.db.execute('BEGIN IMMEDIATE')
            self.expect(etag)
            action()
            self.db.execute('UPDATE meta SET generation=generation+1')
            self.db.execute('INSERT INTO audit(account_id,operation,at) VALUES(?,?,?)', (account_id, operation, now()))
            self.db.commit()
        except BaseException:
            self.db.rollback()
            raise
        return None

    def record_check(self, account, result):
        with self.db:
            self.db.execute('INSERT INTO checks(account_id,result) VALUES(?,?)', (account['id'], json.dumps(result)))
            self.db.execute('UPDATE accounts SET probe=? WHERE id=? AND config_revision=?',
                            (json.dumps(result), account['id'], account['config_revision']))

    def close(self):
        self.db.close()

    def all(self):
        return self.db.execute('SELECT * FROM accounts ORDER BY rowid').fetchall()

    def find(self, account_id):
        return self.db.execute('SELECT * FROM accounts WHERE id=?', (account_id,)).fetchone()

    def next_revision(self):
        return self.db.execute('SELECT generation+1 FROM meta').fetchone()[0]

    def put(self, account_id, config, enabled, blob, revision, config_revision, probe):
        self.db.execute('''INSERT INTO accounts VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET config=excluded.config, credential=excluded.credential,
            credential_revision=excluded.credential_revision, config_revision=excluded.config_revision, probe=excluded.probe''',
            (account_id,json.dumps(config),enabled,blob,revision,config_revision,probe))

    def set_enabled(self, account_id, enabled):
        self.db.execute('UPDATE accounts SET enabled=? WHERE id=?', (enabled,account_id))

    def remove(self, account_id):
        self.db.execute('DELETE FROM accounts WHERE id=?',(account_id,))
