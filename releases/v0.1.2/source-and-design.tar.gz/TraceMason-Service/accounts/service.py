import ipaddress
import re
from urllib.parse import urlsplit
from errors import ServiceError
from provider.profiles import PROFILES

FIELDS = ('name', 'base_url', 'api_key_env', 'model', 'protocol', 'model_mode',
          'auth_type', 'provider_kind', 'credential_mode')


def normalize(value):
    if not isinstance(value, dict):
        raise ServiceError(400, 'invalid_provider', '账号配置必须为对象。')
    account_id = value.get('id')
    if not isinstance(account_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', account_id):
        raise ServiceError(400, 'invalid_provider_id', '账号标识格式无效。', 'id')
    result = {}
    defaults = {'api_key_env': '', 'model': '', 'protocol': 'responses', 'model_mode': 'preserve', 'credential_mode': 'managed'}
    for field in FIELDS:
        text = value.get(field, defaults.get(field))
        if not isinstance(text, str) or (field not in ('model', 'api_key_env') and not text.strip()) or (field != 'model' and len(text) > 512):
            raise ServiceError(400, 'invalid_provider', '请检查账号配置字段。', field)
        result[field] = text.strip()
    for field, choices in [('provider_kind', PROFILES), ('auth_type', ('bearer', 'x_api_key')),
                           ('credential_mode', ('managed', 'env')), ('model_mode', ('preserve',))]:
        if result[field] not in choices:
            raise ServiceError(400, 'invalid_provider', '配置选项无效。', field)
    if result['credential_mode'] == 'env' and not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', result['api_key_env']):
        raise ServiceError(400, 'invalid_key_env', '环境变量名称无效。', 'api_key_env')
    try:
        raw = result['base_url']
        u = urlsplit(raw)
        port = u.port
        local = u.hostname == 'localhost'
        try:
            local = local or ipaddress.ip_address(u.hostname or '').is_loopback
        except ValueError:
            pass
        if (not u.hostname or u.username is not None or u.password is not None
                or '?' in raw or '#' in raw or '\\' in raw or any(c.isspace() or ord(c) < 32 for c in raw)
                or not (u.scheme == 'https' or (u.scheme == 'http' and local))):
            raise ValueError()
    except ValueError:
        raise ServiceError(400, 'invalid_base_url', '使用 HTTPS 或本机 HTTP；地址不能包含凭据、查询或片段。', 'base_url')
    result['base_url'] = raw.rstrip('/')
    key = value.get('api_key', '')
    if not isinstance(key, str) or any(ord(c) < 32 or ord(c) > 126 for c in key):
        raise ServiceError(400, 'invalid_provider', 'API Key 必须是可用的 HTTP 认证值。', 'api_key')
    return account_id, result, key.strip()


import asyncio
import json
import os
from concurrent.futures import ThreadPoolExecutor
from accounts.repository import AccountRepository
from accounts.credential_store import CredentialStore


class AccountService:
    def __init__(self, path, key):
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="accounts-db")
        self.repo = self.executor.submit(AccountRepository, path, CredentialStore(key)).result()

    async def call(self, method, *args):
        return await asyncio.get_running_loop().run_in_executor(self.executor, lambda: getattr(self, method)(*args))

    async def close(self):
        await self.call("_close")
        self.executor.shutdown(wait=True)

    def _close(self):
        self.repo.close()

    def view(self):
        return self.snapshot(), self.repo.etag

    def mutate(self, *args):
        self.repo.mutate(*args)
        return self.view()

    def expect(self, etag):
        self.repo.expect(etag)

    def checked_account(self, account_id, etag):
        self.expect(etag)
        return self.resolve(account_id, True)

    def record_check(self, *args):
        self.repo.record_check(*args)

    def public(self, row):
        config = json.loads(row['config'])
        configured = bool(row['credential']) if config['credential_mode'] == 'managed' else bool(os.environ.get(config['api_key_env']))
        return dict(config, enabled=bool(row['enabled']), configured=configured,
                    has_api_key=bool(row['credential']), credential_revision=row['credential_revision'],
                    probe=json.loads(row['probe']) if row['probe'] else None)

    def snapshot(self):
        return {'providers': {r['id']: self.public(r) for r in self.repo.all()}}

    def save(self, value, etag):
        account_id, config, key = normalize(value)
        intent = value.get('intent')
        if intent not in ('create', 'update'):
            raise ServiceError(400, 'invalid_provider', '需指定创建或更新。')

        def action():
            old = self.repo.find(account_id)
            if intent == 'create' and old:
                raise ServiceError(409, 'provider_exists', '账号标识已存在。', 'id')
            if intent == 'update' and not old:
                raise ServiceError(404, 'provider_not_found', '账号不存在。')
            revision = old['credential_revision'] if old else 0
            blob = old['credential'] if old else None
            if config['credential_mode'] == 'managed':
                if key:
                    revision += 1
                    blob = self.repo.credentials.encrypt(key, account_id, revision)
                if not blob:
                    raise ServiceError(400, 'invalid_provider', '新账号需要填写 API Key。', 'api_key')
            else:
                if blob:
                    revision += 1
                blob = None
            previous = json.loads(old['config']) if old else {}
            changed = not old or bool(key) or any(config[k] != previous.get(k) for k in ('base_url','auth_type','credential_mode','api_key_env','provider_kind','protocol'))
            probe = old['probe'] if old and not changed else None
            config_revision = self.repo.next_revision() if changed else old['config_revision']
            self.repo.put(account_id,config,old['enabled'] if old else 1,blob,revision,config_revision,probe)
        return self.mutate(etag, intent, account_id, action)

    def enable(self, account_id, enabled, etag):
        if type(enabled) is not bool:
            raise ServiceError(400, 'invalid_provider', '启用状态必须为布尔值。')
        def action():
            self.repo.row(account_id)
            self.repo.set_enabled(account_id,enabled)
        return self.mutate(etag, 'enable' if enabled else 'disable', account_id, action)

    def delete(self, account_id, etag):
        def action():
            self.repo.row(account_id)
            self.repo.remove(account_id)
        return self.mutate(etag, 'delete', account_id, action)

    def resolve(self, account_id, allow_disabled=False):
        row = self.repo.row(account_id)
        config = json.loads(row['config'])
        if not row['enabled'] and not allow_disabled:
            raise ServiceError(409, 'provider_disabled', '账号已停用。')
        if config['credential_mode'] == 'managed':
            key = self.repo.credentials.decrypt(row['credential'], account_id, row['credential_revision']) if row['credential'] else ''
        else:
            key = os.environ.get(config['api_key_env'], '')
        if not key:
            raise ServiceError(409, 'provider_not_configured', '账号凭据未配置。')
        if any(ord(c) < 32 or ord(c) > 126 for c in key):
            raise ServiceError(409, 'provider_not_configured', '账号凭据不是有效的 HTTP 认证值。')
        return dict(config, id=account_id, key=key, config_revision=row['config_revision'])

