import base64
import os
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class CredentialStore:
    def __init__(self, key):
        if len(key) != 32:
            raise ValueError('Master key must contain 32 bytes')
        self.cipher = AESGCM(key)

    def encrypt(self, value, account_id, revision):
        nonce = os.urandom(12)
        return nonce + self.cipher.encrypt(nonce, value.encode(), f'{account_id}:{revision}'.encode())

    def decrypt(self, blob, account_id, revision):
        return self.cipher.decrypt(blob[:12], blob[12:], f'{account_id}:{revision}'.encode()).decode()


def load_master_key(path, existing_database=False):
    supplied = os.environ.get('TRACEMASON_MASTER_KEY')
    if supplied:
        return base64.b64decode(supplied, validate=True)
    path = Path(path)
    if not path.exists():
        if existing_database:
            raise RuntimeError('Master key missing for existing database; restore the original key.')
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        key = os.urandom(32)
        try:
            fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            return path.read_bytes()
        with os.fdopen(fd, 'wb') as out:
            out.write(key)
            out.flush()
            os.fsync(out.fileno())
    if path.stat().st_mode & 0o077:
        raise RuntimeError('Master key file must have permissions 0600.')
    return path.read_bytes()
