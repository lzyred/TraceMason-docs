from multidict import CIMultiDict

HOP = {'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization',
       'te', 'trailer', 'transfer-encoding', 'upgrade'}
LOCAL = {'authorization', 'x-api-key', 'x-tracemason-token', 'cookie', 'host', 'content-length'}


def clean_headers(headers, request=False):
    pairs = list(headers.items())
    nominated = {part.strip().lower() for key, value in pairs if key.lower() == 'connection' for part in value.split(',')}
    excluded = HOP | nominated | (LOCAL if request else set())
    return CIMultiDict((key, value) for key, value in pairs if key.lower() not in excluded)


def authenticated_headers(headers, account):
    result = clean_headers(headers, request=True)
    if account['auth_type'] == 'x_api_key':
        result['x-api-key'] = account['key']
    else:
        result['Authorization'] = 'Bearer ' + account['key']
    return result
