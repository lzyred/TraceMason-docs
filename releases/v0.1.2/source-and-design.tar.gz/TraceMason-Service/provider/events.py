"""Bounded, best-effort metadata outbox. No bodies, query strings or credentials."""
import asyncio
from collections import deque

class TransferEvents:
    def __init__(self, capacity=256):
        self.queue = asyncio.Queue(maxsize=capacity)
        self.recent = deque(maxlen=capacity)
        self.dropped = 0
        self.task = None

    def publish(self, event):
        try:
            self.queue.put_nowait(event)
        except asyncio.QueueFull:
            self.dropped += 1

    async def consume(self):
        while True:
            event = await self.queue.get()
            self.recent.append(event)
            self.queue.task_done()

    def start(self):
        self.task = asyncio.create_task(self.consume())

    async def close(self):
        self.task.cancel()
        await asyncio.gather(self.task, return_exceptions=True)
