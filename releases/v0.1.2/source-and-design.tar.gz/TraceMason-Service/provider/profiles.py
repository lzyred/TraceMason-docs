"""Single source of UI presets, authentication defaults and optional check samples."""
PROFILES = {
 'openai': {'name':'OpenAI / Codex', 'base_url':'https://api.openai.com/v1', 'auth_type':'bearer','protocol':'responses','path':'/responses','headers':{'Content-Type':'application/json'},'sample':{'input':'Reply OK.','stream':True}},
 'deepseek': {'name':'DeepSeek','base_url':'https://api.deepseek.com','auth_type':'bearer','protocol':'chat_completions','path':'/chat/completions','headers':{'Content-Type':'application/json'},'sample':{'messages':[{'role':'user','content':'Reply OK.'}],'stream':True}},
 'claude': {'name':'Claude','base_url':'https://api.anthropic.com/v1','auth_type':'x_api_key','protocol':'messages','path':'/messages','headers':{'Content-Type':'application/json','anthropic-version':'2023-06-01'},'sample':{'messages':[{'role':'user','content':'Reply OK.'}],'max_tokens':64,'stream':True}},
 'custom': {'name':'自定义 API','base_url':'','auth_type':'bearer','protocol':'custom','path':'/','headers':{'Content-Type':'application/json'},'sample':{}}
}
