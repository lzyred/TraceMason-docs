"""Transparent WebSocket upgrade: preserve handshake and stream opaque frame bytes.
Uses aiohttp's upgrade parser hook (covered by integration tests; dependency pinned).
"""
import asyncio
import ssl
from aiohttp import web
from errors import ServiceError
from provider.auth import authenticated_headers

class RawUpgrade:
    def __init__(self, protocol):
        self.protocol = protocol
        self.queue = asyncio.Queue()
        self.buffered = 0

    def feed_data(self, data):
        self.buffered += len(data)
        self.queue.put_nowait(data)
        if self.buffered >= 262144:
            self.protocol.pause_reading()
        return False, b''

    def feed_eof(self):
        self.queue.put_nowait(None)

    async def read(self):
        data = await self.queue.get()
        if data is not None:
            self.buffered -= len(data)
            if self.buffered < 131072:
                self.protocol.resume_reading()
        return data


async def tunnel(request, account, url, connect_timeout, idle_timeout):
    writer = None
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(url.host, url.port,
            ssl=ssl.create_default_context() if url.scheme=='https' else None,
            server_hostname=url.host if url.scheme=='https' else None), connect_timeout)
        headers = authenticated_headers(request.headers, account)
        headers['Host'] = url.raw_authority
        headers['Connection'] = 'Upgrade'
        headers['Upgrade'] = 'websocket'
        # Unlike ws_connect, the original key/extensions are preserved end to end.
        lines = [f'{request.method} {url.raw_path_qs} HTTP/1.1']
        lines += [f'{k}: {v}' for k,v in headers.items()]
        writer.write(('\r\n'.join(lines)+'\r\n\r\n').encode('latin1'))
        await writer.drain()
        head = await asyncio.wait_for(reader.readuntil(b'\r\n\r\n'), idle_timeout)
        try:
            status = int(head.split(b' ',2)[1])
        except (ValueError,IndexError):
            raise ServiceError(502,'upstream_handshake','上游握手格式无效。')
        # Forward the original handshake. No redirect following or extension rewriting.
        request.transport.write(head)
        request['transfer_outcome'] = 'complete'
        response = web.StreamResponse(status=status)
        response._eof_sent = True  # Raw handshake already sent; suppress HTTP serialization.
        if status != 101:
            # Non-upgrade HTTP responses are relayed until framed body is complete.
            lower = head.lower()
            length = next((int(line.split(b':',1)[1]) for line in lower.split(b'\r\n') if line.startswith(b'content-length:')),None)
            if length is not None:
                while length:
                    data = await asyncio.wait_for(reader.read(min(65536,length)),idle_timeout)
                    if not data: break
                    request.transport.write(data);length -= len(data)
                    await request._payload_writer.drain()
            elif b'transfer-encoding: chunked' in lower:
                while True:
                    line = await asyncio.wait_for(reader.readline(),idle_timeout)
                    size = int(line.split(b';')[0],16)
                    request.transport.write(line)
                    if not size:
                        while True:
                            trailer = await reader.readline();request.transport.write(trailer)
                            if trailer == b'\r\n':break
                        break
                    request.transport.write(await reader.readexactly(size+2))
                    await request._payload_writer.drain()
            else:
                while True:
                    data = await asyncio.wait_for(reader.read(65536),idle_timeout)
                    if not data:break
                    request.transport.write(data)
                    await request._payload_writer.drain()
            request.transport.close()
            return response
        parser = RawUpgrade(request.protocol)
        request.protocol.set_parser(parser)
        async def upload():
            while True:
                data = await parser.read()
                if data is None:return
                writer.write(data)
                await writer.drain()
        async def download():
            while True:
                data = await asyncio.wait_for(reader.read(65536),idle_timeout)
                if not data:return
                request.transport.write(data)
                await request._payload_writer.drain()
        tasks = [asyncio.create_task(upload()),asyncio.create_task(download())]
        try:
            done,_ = await asyncio.wait(tasks,return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                task.result()
        finally:
            for task in tasks:task.cancel()
            await asyncio.gather(*tasks,return_exceptions=True)
            if request.transport:request.transport.close()
        return response
    except asyncio.CancelledError:
        raise
    except (OSError,asyncio.TimeoutError,asyncio.IncompleteReadError,ValueError) as exc:
        if request.get('transfer_outcome'):
            request['transfer_outcome']='failed'
            if request.transport:request.transport.close()
            return response
        raise ServiceError(502,'upstream_handshake','上游 WebSocket 连接或握手失败。') from exc
    finally:
        if writer:
            writer.close()
            try:await writer.wait_closed()
            except OSError:pass
