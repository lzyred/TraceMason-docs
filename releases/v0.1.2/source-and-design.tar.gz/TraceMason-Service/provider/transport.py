"""HTTP/SSE transport. Every request requires a local privacy authorization."""
import asyncio
from urllib.parse import unquote
from contextlib import asynccontextmanager
from multidict import CIMultiDict
import aiohttp
from aiohttp import web, WSMsgType
from yarl import URL
from errors import ServiceError
from provider.auth import authenticated_headers, clean_headers


def target_url(base, relative):
    if not relative.startswith('/') or relative.startswith('//') or '#' in relative or any(ord(c) < 32 or c == '\\' for c in relative):
        raise ServiceError(400, 'invalid_path', '上游路径必须为相对路径。')
    path = relative.split('?', 1)[0]
    # Reject escaped traversal without reserializing the actual target bytes.
    for _ in range(8):
        if '\\' in path or any(segment in ('.', '..') for segment in path.split('/')):
            raise ServiceError(400, 'invalid_path', '不允许路径穿越。')
        decoded = unquote(path)
        if decoded == path:
            break
        path = decoded
    else:
        raise ServiceError(400, 'invalid_path', '路径编码层数过多。')
    return URL(base.rstrip('/') + relative, encoded=True)


class Transport:
    def __init__(self, connect_timeout=15, idle_timeout=120):
        self.connect_timeout, self.idle_timeout = connect_timeout, idle_timeout
        self.session = None
        self.privacy = None

    async def start(self):
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=None, connect=self.connect_timeout, sock_read=self.idle_timeout),
            auto_decompress=False, cookie_jar=aiohttp.DummyCookieJar(), trust_env=False,
            skip_auto_headers={'Accept', 'Accept-Encoding', 'User-Agent', 'Content-Type'})

    async def close(self):
        await self.session.close()

    @asynccontextmanager
    async def request(self, account, method, path, headers, data, source='gateway'):
        if self.privacy is None:
            raise ServiceError(503, 'privacy_unavailable', '发送前检查不可用。')
        approved = await self.privacy.prepare(account, method, path, CIMultiDict(headers), data, source)
        try:
            async with self.approved_request(account, method, approved) as response:
                response._privacy_record_id=approved.record_id
                yield response
        except (ServiceError, asyncio.TimeoutError, aiohttp.ClientError) as exc:
            exc.request_id=approved.record_id
            raise

    @asynccontextmanager
    async def approved_request(self, account, method, approved):
        self.privacy.verify(approved, account)
        # Durable authorization must exist before opening a socket to the provider.
        await self.privacy.repo.call('state', approved.record_id, 'forwarding')
        try:
            current = await self.privacy.accounts.call('resolve', account['id'])
            self.privacy.verify(approved, current)
            if (await self.privacy.repo.call('policy',account['id']))['revision']!=approved.policy_revision:
                raise ServiceError(409,'privacy_changed','策略已变化，请重新检查。')
            if current['key'] != account['key']:
                raise ServiceError(409, 'privacy_changed', '账号凭据已变化，请重新检查。')
            async with self.session.request(method, target_url(account['base_url'], approved.path),
                    headers=authenticated_headers(approved.headers, account), data=approved.body,
                    allow_redirects=False) as response:
                yield response
                await self.privacy.state(approved.record_id, 'completed' if 200 <= response.status < 300 and not getattr(response, '_privacy_incomplete', False) else 'failed')
        except asyncio.CancelledError:
            await self.privacy.state(approved.record_id, 'cancelled')
            raise
        except BaseException:
            await self.privacy.state(approved.record_id, 'failed')
            raise

    async def pipe_response(self, request, upstream):
        response = web.StreamResponse(status=upstream.status, reason=upstream.reason,
                                      headers=clean_headers(upstream.headers))
        # A client following 307/308 could resend its ORIGINAL unsanitized body
        # directly to the supplied URL. Never delegate the egress boundary.
        response.headers.popall('Location', None)
        response.headers.popall('Refresh', None)
        response.headers['X-TraceMason-Request-ID']=getattr(upstream,'_privacy_record_id','')
        response.headers['Cache-Control']='no-store'
        await response.prepare(request)
        try:
            async for chunk in upstream.content.iter_chunked(65536):
                await response.write(chunk)
            await response.write_eof()
        except (aiohttp.ClientError, asyncio.TimeoutError, ConnectionError):
            # Once headers are sent, abort instead of appending synthetic JSON to the body.
            upstream._privacy_incomplete = True
            request['transfer_outcome'] = 'failed'
            if request.transport:
                request.transport.close()
        return response

    async def relay(self, request, account, path):
        try:
            async with self.request(account, request.method, path, request.headers,
                                    request.content.iter_chunked(65536) if request.can_read_body else None) as upstream:
                return await self.pipe_response(request, upstream)
        except (asyncio.TimeoutError, aiohttp.ClientError) as cause:
            exc=ServiceError(504, 'upstream_timeout', '上游响应超时。') if isinstance(cause,asyncio.TimeoutError) else ServiceError(502, 'upstream_unreachable', '无法连接上游。')
            if getattr(cause,'request_id',None):exc.request_id=cause.request_id
            raise exc from None

