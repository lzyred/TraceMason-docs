import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import os from 'node:os';
import path from 'node:path';
const profile=await fs.mkdtemp(path.join(os.tmpdir(),'tm-review-chrome-'));
const child=spawn(process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless=new','--remote-debugging-port=0','--no-first-run','--no-default-browser-check','--disable-background-networking','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
let socket;
const fixture=spawn(fileURLToPath(new URL('../.venv/bin/python',import.meta.url)),[fileURLToPath(new URL('../tests/browser_privacy_fixture.py',import.meta.url))],{stdio:['ignore','pipe','inherit']});
const config=await new Promise((resolve,reject)=>{let log='';fixture.stdout.on('data',b=>{log+=b;if(log.includes('\n'))resolve(JSON.parse(log.split('\n')[0]));});fixture.once('exit',()=>reject(Error('fixture exited')));});
try{
 const endpoint=await new Promise((resolve,reject)=>{let log='';const timer=setTimeout(()=>reject(Error('Chrome start timeout')),15000);child.stderr.on('data',b=>{log+=b;const m=log.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});child.once('error',reject);});
 socket=new WebSocket(endpoint);await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j;});
 let seq=0;const pending=new Map(),errors=[],external=[];
 socket.onmessage=e=>{const d=JSON.parse(e.data);if(d.id){const p=pending.get(d.id);if(p){pending.delete(d.id);d.error?p.reject(Error(JSON.stringify(d.error))):p.resolve(d.result);}}else if(d.method==='Runtime.exceptionThrown')errors.push(d.params.exceptionDetails.text);else if(d.method==='Network.requestWillBeSent'&&/^https?:/.test(d.params.request.url))external.push(d.params.request.url);};
 const call=(method,params={},sessionId)=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});socket.send(JSON.stringify({id,method,params,sessionId}));});
 const {targetId}=await call('Target.createTarget',{url:'about:blank'});const {sessionId}=await call('Target.attachToTarget',{targetId,flatten:true});
 const c=(method,params)=>call(method,params,sessionId);
 await c('Runtime.enable');await c('Page.enable');await c('Network.enable');
 const evaluate=async expression=>{const r=await c('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};

 const until=async expression=>{for(let i=0;i<150;i++){if(await evaluate(expression))return;await new Promise(r=>setTimeout(r,100));}throw Error('timeout '+expression);};



 await c('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
 const click=async selector=>{const point=await evaluate(`new Promise(resolve=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e||e.disabled)throw Error('unavailable '+${JSON.stringify(selector)});e.scrollIntoView({block:'center'});requestAnimationFrame(()=>{const r=e.getBoundingClientRect();resolve({x:e.id==='nav-backdrop'?innerWidth-12:r.x+r.width/2,y:r.y+r.height/2})});})`);await c('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...point});await c('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...point});};
 const fill=async (selector,value)=>evaluate(`document.querySelector(${JSON.stringify(selector)}).value=${JSON.stringify(value)}`);
 const ready=()=>until('!document.body.hasAttribute("aria-busy")');
 const screenshot=async name=>{const shot=await c('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});await fs.mkdir(new URL('../docs/screenshots/',import.meta.url),{recursive:true});await fs.writeFile(new URL('../docs/screenshots/'+name,import.meta.url),Buffer.from(shot.data,'base64'));};
 await c('Page.navigate',{url:config.url+'/privacy.html'});await until('!!document.querySelector("#task-form")');await ready();
 assert.equal(await evaluate('document.querySelectorAll("#destination option").length'),3);
 assert.deepEqual(await evaluate('Array.from(document.querySelectorAll(".nav-children a")).map(a=>a.textContent)'),['防护工作台','外发记录','防护边界']);
 assert.equal(await evaluate('document.querySelectorAll("nav > .service-entry, nav > .nav-group").length'),2);
 assert.equal(await evaluate('document.querySelector("[data-nav=workspace]").getAttribute("aria-current")'),'page');
 assert.match(await evaluate('document.querySelector("#breadcrumb").textContent'),/隐私外发防护 \/ 防护工作台/);
 assert.deepEqual(await evaluate('Array.from(document.querySelectorAll("#task-column > [data-panel]")).map(e=>e.dataset.panel)'),['task','materials']);
 assert.deepEqual(await evaluate('Array.from(document.querySelectorAll("#manifest-panel > [data-panel]")).map(e=>e.dataset.panel)'),['manifest','coverage']);
 assert.equal(await evaluate('Math.abs(document.querySelector("[data-panel=task]").getBoundingClientRect().top-document.querySelector("[data-panel=manifest]").getBoundingClientRect().top)<2'),true);
 assert.equal(await evaluate('document.querySelector("#task-column").getBoundingClientRect().right<document.querySelector("#manifest-panel").getBoundingClientRect().left'),true);
 await screenshot('privacy-layout-empty-desktop.png');

 assert.equal(await evaluate('document.body.textContent.includes("原型")||document.body.textContent.includes("模拟")'),false);
 await fill('#model','future-browser-model');await fill('#purpose','排查配置中的连接失败');await click('#save-task');await until('!!document.querySelector("#add-text") && !document.querySelector("#add-text").disabled');await ready();
 await click('#add-text');await fill('#kind','identity');await fill('#material-text','姓名：张三\npassword=BrowserSecret839\n联系邮箱：privacy@example.net\n错误：连接被拒绝');await click('#add-material');await ready();
 await click('#add-text');await fill('#kind','private');await fill('#material-text','-----BEGIN PRIVATE KEY-----\nNeverSendPrivateKey938\n-----END PRIVATE KEY-----');await click('#add-material');await ready();
 await click('#material-list [data-action=edit]');assert.match(await evaluate('document.querySelector("#replacement").value'),/BrowserSecret839/);await click('#modal-close');
 await click('#material-list [data-action=exclude]');await ready();assert.equal(await evaluate('document.querySelectorAll("#material-list [data-action=include]").length'),1);
 await click('#material-list [data-action=include]');await ready();
 await evaluate(`document.querySelector('#purpose').value='排查配置中的连接失败，保留上下文';document.querySelector('#purpose').dispatchEvent(new Event('input',{bubbles:true}))`);
 await click('[data-nav=policy]');await until('!!document.querySelector("[data-panel=data-actions]")');await ready();
 await click('[data-nav=workspace]');await until('!!document.querySelector("#task-form")');await ready();assert.equal(await evaluate('document.querySelector("#purpose").value'),'排查配置中的连接失败，保留上下文');
 await click('#save-task');await ready();
 await click('#build');await until('!!document.querySelector("[data-action=review]")');await ready();
 assert.equal((await fetch(config.upstream+'/evidence').then(r=>r.json())).captured.length,0);
 assert.deepEqual(await evaluate('Array.from(document.querySelectorAll("#manifest-panel > [data-panel]")).map(e=>e.dataset.panel)'),['manifest','findings','coverage']);
 assert.equal(await evaluate('document.querySelectorAll(".journey li").length'),4);
 assert.match(await evaluate('document.querySelector("[data-panel=findings]").textContent'),/认证秘密/);
 await evaluate('scrollTo(0,0)');await screenshot('privacy-review-desktop.png');
 await click('[data-action=review]');assert.equal(await evaluate('document.querySelector("#review-text").value.includes("BrowserSecret839")'),false);
 await click('#approve');await until('!!document.querySelector("#send") && !document.querySelector("#send").disabled');await ready();
 assert.equal(await evaluate('document.querySelector(".package-preview").textContent.includes("张三")'),false);
 await evaluate('scrollTo(0,0)');await screenshot('privacy-ready-desktop.png');
 await click('#send');await until('document.querySelector("#response-state")?.textContent==="已完成"');
 const evidence=await fetch(config.upstream+'/evidence').then(r=>r.json());assert.equal(evidence.captured.length,1);const sent=JSON.stringify(evidence.captured);
 for(const secret of ['张三','BrowserSecret839','privacy@example.net','NeverSendPrivateKey938'])assert.ok(!sent.includes(secret));assert.ok(sent.includes('连接被拒绝'));assert.ok(sent.includes('future-browser-model'));
 assert.match(await evaluate('document.querySelector("#response").textContent'),/发送前处理/);
 assert.equal(await evaluate('document.querySelector("#send").disabled'),true);assert.match(await evaluate('document.querySelector("[data-panel=manifest]").textContent'),/已完成/);
 assert.equal(await evaluate('document.querySelector("[data-panel=response]").parentElement.id'),'task-column');
 await screenshot('privacy-sent-desktop.png');
 await fill('#purpose','下一轮继续分析张三的错误');await click('#next-round');await ready();await click('#build');await ready();
 await click('[data-action=review]');await click('#approve');await until('!!document.querySelector("#send") && !document.querySelector("#send").disabled');await ready();
 assert.equal(await evaluate('document.querySelector(".package-preview").textContent.includes("张三")'),false);
 await evaluate('location.hash="records"');await until('!!document.querySelector("#filters")');await ready();assert.ok(await evaluate('document.querySelectorAll("tbody tr").length>=3'));
 assert.match(await evaluate('document.querySelector("thead").textContent'),/轮次.*保留 \/ 排除/);
 assert.match(await evaluate('document.querySelector("tbody").textContent'),/第 1 轮/);
 assert.match(await evaluate('document.querySelector("tbody").textContent'),/1 \/ 1/);
 assert.equal(await evaluate('document.querySelector("[data-nav=records]").getAttribute("aria-current")'),'page');
 await evaluate('scrollTo(0,0)');await screenshot('privacy-records-desktop.png');
 await click('#delete-records');await until('!!document.querySelector("#delete-confirm")');await ready();await click('#delete-confirm');await ready();await until('document.querySelector(".empty")?.textContent.includes("暂无记录")');
 await evaluate('location.hash="policy"');await until('!!document.querySelector(".policy-card")');await ready();
 assert.match(await evaluate('document.body.textContent'),/未知密钥格式/);
 await c('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await until('document.querySelector("#sidebar").getBoundingClientRect().right<=0.5');
 assert.equal(await evaluate('document.documentElement.scrollWidth<=innerWidth'),true);
 await evaluate('scrollTo(0,0)');await screenshot('privacy-policy-mobile.png');
 await evaluate('location.hash="workspace"');await until('!!document.querySelector("#task-form")');await ready();
 assert.equal(await evaluate('document.documentElement.scrollWidth<=innerWidth'),true);await evaluate('scrollTo(0,0)');await screenshot('privacy-workspace-mobile.png');
 await click('#nav-toggle');assert.equal(await evaluate('document.querySelector("#nav-toggle").getAttribute("aria-expanded")'),'true');await until('document.querySelector("#sidebar").getBoundingClientRect().x >= -0.5');await screenshot('privacy-navigation-mobile.png');await click('#nav-backdrop');await until('document.querySelector("#sidebar").getBoundingClientRect().right<=0.5');
 await click('#end-task');await click('#end-confirm');await until('!document.querySelector("#end-task")');await ready();
 assert.equal(await evaluate('localStorage.length+sessionStorage.length'),0);
 await c('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
 await evaluate('location.hash="policy"');await until('!!document.querySelector("#policy-form") && !!document.querySelector("#policy-version").textContent');await ready();
 await fill('#secret-action','block');await click('#save-policy');await ready();assert.match(await evaluate('document.querySelector("#policy-version").textContent'),/v2/);
 await fill('#trial-json',JSON.stringify({model:'trial-only',input:'password=BrowserTrialSecret930'}));await click('#trial-form button');await ready();assert.match(await evaluate('document.querySelector("#trial-result").textContent'),/拦截/);assert.equal(await evaluate('document.querySelector("#trial-result").textContent.includes("BrowserTrialSecret930")'),false);
 assert.equal((await fetch(config.upstream+'/evidence').then(r=>r.json())).captured.length,1);
 await evaluate('scrollTo(0,400)');await screenshot('privacy-policy-hardening.png');
 const blockedResponse=await fetch(config.gateway+'/proxy/openai/responses',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:'delayed-native',input:'password=BrowserBlockedSecret782\nError 502',stream:true,temperature:0.25})});assert.equal(blockedResponse.status,409);const blocked=await blockedResponse.json();assert.ok(blocked.error.request_id);assert.equal(blocked.error.review_available,true);
 assert.equal((await fetch(config.upstream+'/evidence').then(r=>r.json())).captured.length,1);
 await evaluate('location.hash="records"');await until('!!document.querySelector('+JSON.stringify('[data-record="'+blocked.error.request_id+'"]')+')');await ready();
 await click('[data-record="'+blocked.error.request_id+'"]');await until('!!document.querySelector("#recover-request")');await ready();assert.equal(await evaluate('document.querySelector("#modal-body").textContent.includes("BrowserBlockedSecret782")'),false);await screenshot('privacy-record-reason.png');
 await click('#recover-request');await until('!!document.querySelector("[data-action=review]")');await ready();assert.equal(await evaluate('document.querySelector("#add-text").disabled'),true);
 await click('[data-action=review]');assert.equal(await evaluate('document.querySelector("#review-text").value.includes("BrowserBlockedSecret782")'),false);await click('#approve');await until('!!document.querySelector("#send")&&!document.querySelector("#send").disabled');await ready();
 await click('#send');assert.notEqual(await evaluate('document.querySelector("#response-state")?.textContent'),'已完成');await until('document.querySelector("#response-state")?.textContent==="已完成"');
 const nativeEvidence=(await fetch(config.upstream+'/evidence').then(r=>r.json())).captured;assert.equal(nativeEvidence.length,2);assert.equal(nativeEvidence[1].temperature,0.25);assert.equal(nativeEvidence[1].model,'delayed-native');assert.ok(!JSON.stringify(nativeEvidence).includes('BrowserBlockedSecret782'));
 await screenshot('privacy-recovered-request.png');
 await click('#end-task');await click('#end-confirm');await ready();await until('!document.querySelector("#end-task")');

 // Real product requests for both remaining protocols and a non-2xx response.
 for(const [account,protocol,model,expected]of [['deepseek','chat_completions','future-deepseek','已完成'],['claude','messages','future-claude','已完成'],['openai','responses','denied-native','失败']]){
  await fill('#destination',account);await fill('#protocol',protocol);await fill('#model',model);await fill('#purpose','Explain HTTP 502 and retries');await click('#save-task');await ready();
  await click('#build');await until('!!document.querySelector("#send")&&!document.querySelector("#send").disabled');await ready();await click('#send');await until('document.querySelector("#response-state")?.textContent==='+JSON.stringify(expected));
  if(expected==='已完成')assert.match(await evaluate('document.querySelector("#response").textContent'),/敏感内容已在发送前处理/);
  else {assert.match(await evaluate('document.querySelector("[data-panel=manifest]").textContent'),/失败/);assert.equal(await evaluate('document.querySelector("[data-panel=manifest] .decision-box h2").textContent'),'失败');await screenshot('privacy-failed-response.png');}
  const captures=(await fetch(config.upstream+'/evidence').then(r=>r.json())).captured;assert.equal(captures.at(-1).model,model);
  await click('#end-task');await click('#end-confirm');await ready();await until('!document.querySelector("#end-task")');
 }

 await c('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
 await c('Page.navigate',{url:new URL('../../TraceMason-docs/design/v0.1.2/index.html',import.meta.url).href});await until('document.querySelectorAll(".mermaid svg").length===10');
 assert.equal(await evaluate('document.querySelectorAll(".error-icon").length'),0);
 await screenshot('privacy-architecture.png');
 await c('Page.navigate',{url:new URL('../../TraceMason-docs/design/v0.1.2/navigation.html',import.meta.url).href});await until('document.querySelectorAll(".mermaid svg").length===4');
 assert.equal(await evaluate('document.querySelectorAll(".error-icon").length'),0);await screenshot('privacy-navigation-mapping.png');
 await c('Page.navigate',{url:new URL('../../TraceMason-docs/design/v0.1.2/hardening.html',import.meta.url).href});await until('document.querySelectorAll(".mermaid svg").length===6');
 assert.equal(await evaluate('document.querySelectorAll(".error-icon").length'),0);await screenshot('privacy-security-architecture.png');
 await c('Page.navigate',{url:new URL('../../TraceMason-docs/design/v0.1.2/reliability.html',import.meta.url).href});await until('document.querySelectorAll(".mermaid svg").length===5');assert.equal(await evaluate('document.querySelectorAll(".error-icon").length'),0);await screenshot('privacy-reliability.png');
 if(process.env.VERIFY_CONTAINER==='1'){
  await c('Page.navigate',{url:'http://127.0.0.1:8766/privacy.html'});await until('!!document.querySelector("#task-form")');await ready();
  assert.equal(await evaluate('document.body.textContent.includes("原型")||document.body.textContent.includes("模拟")'),false);
  assert.equal(await evaluate('document.querySelectorAll("nav > .service-entry, nav > .nav-group").length'),2);assert.equal(await evaluate('document.querySelectorAll(".nav-children [data-nav]").length'),3);
  await screenshot('privacy-container-live.png');
  assert.equal(await evaluate('document.querySelector("[data-panel=task]").parentElement.id'),'task-column');assert.equal(await evaluate('document.querySelector("[data-panel=manifest]").parentElement.id'),'manifest-panel');
  await evaluate('location.hash="policy"');await until('!!document.querySelector(".policy-card")');await ready();assert.match(await evaluate('document.body.textContent'),/local-context-3/);
 }
 assert.deepEqual(errors,[]);assert.ok(external.every(url=>url.startsWith(config.url+'/')||url.startsWith('http://127.0.0.1:8766/')));
 console.log('PASS real browser: task creation, identity review, private-file exclusion, actual outbound traffic, SSE, second-round aliases, records/deletion, desktop/mobile, account policies/trial, blocked-request recovery, preserved native parameters, reason records, truthful completion states, three protocol SSE with split UTF-8, HTTP401 failure, six security diagrams, no browser content storage.');
}finally{if(socket)socket.close();child.kill('SIGTERM');fixture.kill('SIGTERM');}
