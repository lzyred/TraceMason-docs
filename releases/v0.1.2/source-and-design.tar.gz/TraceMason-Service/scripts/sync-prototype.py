"""Generate review UI from production sources; mock transport remains review-only."""
import json
import sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from provider.profiles import PROFILES
out=root.parent/'TraceMason-docs/design/v0.1.1/prototype'
for name in ('app.css','contract.js','api-client.js','app.js','index.html'):
    text=(root/'web'/name).read_text()
    if name=='app.js':
        text=text.replace('new SameOriginProviderTransport()', 'new ReviewTransport()')
        text=text.replace('每个账号独立加密保存凭据。','评审模式：仅模拟凭据状态，不保存密钥。')
    if name=='index.html':
        text=text.replace('填写上游 API Key','仅填写虚构示例 Key').replace('密钥加密保存在服务端，保存后不回显。','评审模式：不保存输入的 Key，请勿输入真实凭据。')
        text=text.replace('<script src="contract.js','<div class="prototype-bar">v0.1.1 · 本地模拟评审 · <a href="http://127.0.0.1:8766">打开真实服务</a></div><script src="profiles.generated.js"></script><script src="mock-api.js"></script><script src="review-transport.js"></script><script src="contract.js',1)
    (out/name).write_text(text)
(out/'profiles.generated.js').write_text('globalThis.ReviewProfiles='+json.dumps(PROFILES,ensure_ascii=False)+';\n')
(out/'review-transport.js').write_text('''class ReviewTransport {
 constructor(){this.mock=new MockProviderTransport();}
 async request(method,path,body,headers,signal){
  if(path==='/api/provider-profiles')return {status:200,headers:{},body:{profiles:ReviewProfiles,gateway_url:'http://127.0.0.1:8768'}};
  if(signal?.aborted)throw new DOMException('已取消','AbortError');
  return this.mock.request(method,path,body,headers);
 }
}
''')
