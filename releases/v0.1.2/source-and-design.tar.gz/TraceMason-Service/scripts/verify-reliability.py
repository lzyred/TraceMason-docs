"""Run the cross-channel suite and write its actual evidence, including failures."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import unittest
from datetime import datetime
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import test_cross_validation as cross
from privacy.standards import RULESET
parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
suite=unittest.defaultTestLoader.loadTestsFromModule(cross)
result=unittest.TextTestRunner(verbosity=2).run(suite)
counts={label:sum(row['expected']==label for row in cross.CrossChannelTests.results)for label in ['blocked','redacted','unchanged']}
report={'checked_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'ruleset':RULESET,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful(),'matrix_expected':len(cross.CASES)*len(cross.PROTOCOLS),'matrix_passed':len(cross.CrossChannelTests.results),'counts':counts,'fixture_sha256':hashlib.sha256((ROOT/'tests/privacy_cross_cases.json').read_bytes()).hexdigest(),'detector_sha256':hashlib.sha256((ROOT/'privacy/detector.py').read_bytes()).hexdigest(),'fixture_count':len(cross.CASES),'scope':'synthetic development fixtures; local HTTP upstream; no live vendor calls; not representative privacy recall or precision','oracles':['explicit secret absence and useful-content retention','unchanged negative JSON equality','detector vs trial vs actual upstream','record reason/decision/version/state consistency','on-disk canary absence'],'matrix':cross.CrossChannelTests.results}
Path(args.output).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
sys.exit(0 if result.wasSuccessful()else 1)
