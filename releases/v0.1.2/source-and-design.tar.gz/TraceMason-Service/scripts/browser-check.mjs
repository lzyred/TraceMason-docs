import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import os from 'node:os';
import path from 'node:path';
const profile=await fs.mkdtemp(path.join(os.tmpdir(),'tm-review-chrome-'));
const child=spawn(process.env.CHROME_PATH||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless=new','--remote-debugging-port=0','--no-first-run','--no-default-browser-check','--disable-background-networking','--user-data-dir='+profile,'about:blank'],{stdio:['ignore','ignore','pipe']});
let socket;
const fixture=spawn(fileURLToPath(new URL('../.venv/bin/python',import.meta.url)),[fileURLToPath(new URL('../tests/browser_fixture.py',import.meta.url))],{stdio:['ignore','pipe','inherit']});
const config=await new Promise((resolve,reject)=>{let log='';fixture.stdout.on('data',b=>{log+=b;if(log.includes('\n'))resolve(JSON.parse(log.split('\n')[0]));});fixture.once('exit',()=>reject(Error('fixture exited')));});
try{
 const endpoint=await new Promise((resolve,reject)=>{let log='';const timer=setTimeout(()=>reject(Error('Chrome start timeout')),15000);child.stderr.on('data',b=>{log+=b;const m=log.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timer);resolve(m[1]);}});child.once('error',reject);});
 socket=new WebSocket(endpoint);await new Promise((r,j)=>{socket.onopen=r;socket.onerror=j;});
 let seq=0;const pending=new Map(),errors=[],external=[];
 socket.onmessage=e=>{const d=JSON.parse(e.data);if(d.id){const p=pending.get(d.id);if(p){pending.delete(d.id);d.error?p.reject(Error(JSON.stringify(d.error))):p.resolve(d.result);}}else if(d.method==='Runtime.exceptionThrown')errors.push(d.params.exceptionDetails.text);else if(d.method==='Network.requestWillBeSent'&&/^https?:/.test(d.params.request.url))external.push(d.params.request.url);};
 const call=(method,params={},sessionId)=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});socket.send(JSON.stringify({id,method,params,sessionId}));});
 const {targetId}=await call('Target.createTarget',{url:'about:blank'});const {sessionId}=await call('Target.attachToTarget',{targetId,flatten:true});
 const c=(method,params)=>call(method,params,sessionId);
 await c('Runtime.enable');await c('Page.enable');await c('Network.enable');
 const evaluate=async expression=>{const r=await c('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};

 const until=async expression=>{for(let i=0;i<150;i++){if(await evaluate(expression))return;await new Promise(r=>setTimeout(r,100));}throw Error('timeout '+expression);};



 await c('Page.navigate',{url:config.url});await until('document.querySelector("#refresh") && !document.querySelector("#refresh").disabled');
 const click=async selector=>{const point=await evaluate(`new Promise(resolve=>{const e=document.querySelector(${JSON.stringify(selector)});if(e?.closest('.row-menu'))e.closest('.row-menu').open=true;if(!e||e.disabled)throw Error('unavailable '+${JSON.stringify(selector)});e.scrollIntoView({block:'center'});requestAnimationFrame(()=>{const r=e.getBoundingClientRect();resolve({x:r.x+r.width/2,y:r.y+r.height/2})});})`);await c('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',clickCount:1,...point});await c('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',clickCount:1,...point});};
 const ready=()=>until('!document.querySelector("#refresh").disabled');
 const snapshot=()=>evaluate('fetch("/api/providers").then(r=>r.json())');
 assert.equal(await evaluate('document.querySelectorAll(".sidebar nav > .service-entry, .sidebar nav > .nav-group").length'),2);assert.equal(await evaluate('document.querySelectorAll(".nav-children a").length'),3);assert.equal(await evaluate('document.querySelectorAll("header nav").length'),0);
 assert.equal(await evaluate('document.querySelector("nav").textContent.includes("API 接入")'),true);
 for(const kind of ['openai','deepseek','claude']){
  await click('#new-provider');await click('[data-platform='+kind+']');
  await evaluate(`Object.assign(document.querySelector('#provider-form').elements.id,{value:${JSON.stringify(kind)}});document.querySelector('#provider-form').elements.base_url.value=${JSON.stringify(config.upstream)};document.querySelector('#provider-form').elements.api_key.value='browser-secret-'+${JSON.stringify(kind)}`);
  await click('#save-only');await ready();assert.ok((await snapshot()).providers[kind]);
 }
 await click('[data-provider=openai] [data-action=connect]');assert.equal(await evaluate('document.querySelector("#connection-url").value'),config.gateway+'/proxy/openai/');assert.match(await evaluate('document.querySelector("#connection-example").textContent'),/YOUR_MODEL/);assert.equal(await evaluate('document.querySelector("#connection-example").textContent.includes(String.fromCharCode(92)+"n")'),false);await click('[data-close=connect-guide]');
 await click('#new-provider');assert.ok(await evaluate('document.querySelector("#provider-form").elements.id.value.startsWith("openai-")'));assert.equal(await evaluate('document.querySelector("#account-advanced").open'),false);await click('[data-close=editor]');
 await click('[data-provider=openai] [data-action=edit]');assert.equal(await evaluate('document.querySelector("#provider-form").elements.api_key.value'),'');await evaluate(`document.querySelector('#provider-form').elements.name.value='API 工作账号'`);await click('#save-only');await ready();assert.equal((await snapshot()).providers.openai.credential_revision,1);
 await click('[data-provider=deepseek] [data-action=toggle]');await ready();assert.equal((await snapshot()).providers.deepseek.enabled,false);
 await click('[data-provider=deepseek] [data-action=toggle]');await ready();
 await click('[data-provider=openai] [data-action=test]');await evaluate(`document.querySelector('#check-model').value='unrestricted-model-v999'`);await click('#probe-run');await until('document.querySelector("#probe-cancel").hidden');await ready();assert.match(await evaluate('document.querySelector("#probe-content").textContent'),/检查请求|HTTP|测试通过/);await click('[data-close=probe]');assert.equal((await snapshot()).providers.openai.probe.ok,true);
 await click('[data-provider=claude] [data-action=test]');await evaluate(`document.querySelector('#custom-probe').open=true;document.querySelector('#probe-path').value='/messages';document.querySelector('#probe-body').value=JSON.stringify({model:'test__denied',messages:[{role:'user',content:'hello'}]})`);await click('#probe-run');await until('document.querySelector("#probe-cancel").hidden');await ready();await click('[data-close=probe]');await click('[data-provider=claude] [data-action=test-detail]');assert.match(await evaluate('document.querySelector("#detail-body").textContent'),/上次测试未通过/);await click('[data-close=detail]');assert.equal((await snapshot()).providers.claude.enabled,true);
 await evaluate(`document.querySelector('#platform-filter').value='deepseek';document.querySelector('#platform-filter').dispatchEvent(new Event('change'))`);assert.equal(await evaluate('document.querySelectorAll("tbody tr").length'),1);await evaluate(`document.querySelector('#platform-filter').value='';document.querySelector('#platform-filter').dispatchEvent(new Event('change'))`);
 await click('[data-provider=openai] [data-action=test]');await evaluate(`document.querySelector('#custom-probe').open=true;document.querySelector('#probe-path').value='/responses';document.querySelector('#probe-body').value=JSON.stringify({model:'test__slow',input:'hello'})`);await click('#probe-run');await until('!document.querySelector("#probe-cancel").hidden');await click('[data-close=probe]');
 await click('[data-provider=deepseek] [data-action=toggle]');await ready();assert.equal((await snapshot()).providers.deepseek.enabled,false);await click('[data-provider=openai] [data-action=cancel]');await until('!document.querySelector("[data-provider=openai] [data-action=cancel]")');await click('[data-provider=deepseek] [data-action=toggle]');await ready();
 await evaluate(`document.querySelector('#page-size').insertAdjacentHTML('beforeend','<option value="1">1</option>');document.querySelector('#page-size').value='1';document.querySelector('#page-size').dispatchEvent(new Event('change'))`);assert.equal(await evaluate('document.querySelectorAll("tbody tr").length'),1);await click('#page-next');assert.match(await evaluate('document.querySelector("#page-number").textContent'),/2 \/ 3/);await evaluate(`document.querySelector('#page-size').value='10';document.querySelector('#page-size').dispatchEvent(new Event('change'))`);
 for(const width of [1440,390]){await c('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:false});await evaluate('scrollTo(0,0)');if(width===390){await click('#navigation-toggle');assert.equal(await evaluate('document.querySelector("#navigation-toggle").getAttribute("aria-expanded")'),'true');await click('.sidebar .service-entry[href="/"]');assert.equal(await evaluate('document.body.classList.contains("navigation-open")'),false);}else{assert.equal(await evaluate('getComputedStyle(document.querySelector(".sidebar")).display'),'flex');}assert.ok(await evaluate('document.documentElement.scrollWidth<=innerWidth'));assert.ok(await evaluate('document.querySelector("#connection-list").getBoundingClientRect().top<innerHeight'));const shot=await c('Page.captureScreenshot',{format:'png'});await fs.mkdir(new URL('../docs/screenshots/',import.meta.url),{recursive:true});await fs.writeFile(new URL('../docs/screenshots/api-access-'+width+'.png',import.meta.url),Buffer.from(shot.data,'base64'));}
 await c('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});await click('[data-provider=deepseek] [data-action=delete]');await click('#confirm-action');await ready();assert.equal((await snapshot()).providers.deepseek,undefined);
 await c('Page.reload');await until('document.querySelector("#connection-list tbody")');assert.equal(Object.keys((await snapshot()).providers).length,2);
 assert.equal(await evaluate('JSON.stringify(localStorage).includes("browser-secret")'),false);assert.equal(await evaluate('typeof window.providerReview'), 'undefined');
 await c('Page.navigate',{url:config.gateway+'/proxy/openai/'});await until('document.readyState==="complete"');
 const blocked=await evaluate(`fetch(${JSON.stringify(config.url+'/api/session')}).then(r=>r.json()).then(()=>false).catch(()=>true)`);assert.equal(blocked,true);
 await c('Page.navigate',{url:new URL('../docs/implementation.html',import.meta.url).href});await until('document.querySelectorAll(".mermaid svg").length===4');
 await c('Page.navigate',{url:new URL('../../TraceMason-docs/design/v0.1.1/index.html',import.meta.url).href});await until('document.body?.dataset.ready === "true"');assert.equal(await evaluate('document.querySelectorAll(".mermaid svg").length'),9);
 await c('Page.navigate',{url:new URL('../docs/review-fixes.html',import.meta.url).href});await until('document.querySelectorAll(".mermaid svg").length===3');
 await c('Page.navigate',{url:new URL('../../TraceMason-docs/design/v0.1.1/prototype/index.html',import.meta.url).href});await until('document.querySelector("#connection-list tbody") && !document.querySelector("#page-error").textContent && !document.querySelector("#refresh").disabled');await click('#new-provider');assert.equal(await evaluate('document.querySelectorAll("[data-platform]").length'),4);await click('[data-close=editor]');
 if(process.env.VERIFY_CONTAINER==='1'){
  await c('Page.navigate',{url:'http://127.0.0.1:8766/'});await until('document.querySelector("#new-provider") && !document.querySelector("#new-provider").disabled && !!document.querySelector("#list-summary")?.textContent');
  assert.equal(await evaluate('document.querySelectorAll("#connected,#add-chooser,.editor-preview,#probe-switch").length'),0);
  assert.equal(await evaluate('document.body.textContent.includes("本地工作空间")||document.body.textContent.includes("本机服务")||document.body.textContent.includes("连接使用指南")||document.body.textContent.includes("原型")||document.body.textContent.includes("模拟")||document.body.textContent.includes("确认切换")'),false);
  await click('#new-provider');assert.equal(await evaluate('document.querySelector("#editor").open'),true);await click('[data-close=editor]');
  const shot=await c('Page.captureScreenshot',{format:'png'});await fs.writeFile(new URL('../docs/screenshots/container-live.png',import.meta.url),Buffer.from(shot.data,'base64'));
  await c('Page.navigate',{url:new URL('../docs/container.html',import.meta.url).href});await until('document.querySelectorAll(".mermaid svg").length===2');
 }
 assert.deepEqual(errors,[]);assert.ok(external.every(url=>url.startsWith(config.url+'/')||url.startsWith(config.gateway+'/')||url.startsWith('http://127.0.0.1:8766/')));
 console.log('PASS real frontend/API: three Providers, encrypted-key edit preservation, enable/disable, actual upstream checks, errors, filter, delete, reload persistence, desktop/mobile, no mock or browser key storage.');
}finally{if(socket)socket.close();child.kill('SIGTERM');fixture.kill('SIGTERM');}
